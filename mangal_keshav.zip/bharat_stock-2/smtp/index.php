<?php
include('PHPMailerAutoload.php');
$html="test";
echo smtp_mailer('nizampatoli@gmail.com','Subject','html');
function smtp_mailer($to,$subject,$msg){

$mail = new PHPMailer();
$mail->IsSMTP();
$mail->SMTPAuth = true;
$mail->SMTPSecure = 'tls';
$mail->Host = "smtp.gmail.com";
$mail->Port = 587;
$mail->IsHTML(true);
$mail->CharSet = 'UTF-8';
$mail->Username = "fyp.ms2020@gmail.com";
$mail->Password = "zwis mxwj idkt euys";
$mail->SetFrom("fyp.ms2020@gmail.com");
$mail->Subject = $subject;
$mail->Body= $msg;
$mail->AddAddress($to);
$mail->SMTPOption=array('ssl'=>array(
	'verify_peer'=>false,
	'verify_peer_name'=>false,
	'verify_peer_signed'=>false,

));

// Set the SMTP port

// Send the email
if ($mail->send()) {
    echo 'Email sent successfully';
} else {
    echo 'Error sending email: ' . $mail->ErrorInfo;
}
}
