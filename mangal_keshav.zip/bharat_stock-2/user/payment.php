<?php
session_start();
require '../classes/Database.php';
require '../classes/User.php';

if (!isset($_SESSION['is_logged_in']) || !$_SESSION['is_logged_in']) {
    header('Location: ../logout.php');
    exit();
}

$database = new Database();
$conn = $database->connDb();

$user_id = $_SESSION['user_id'];
$activeuser = User::getById($conn, $user_id);
$userName = $activeuser['name'];
$userEmail = $activeuser['email'];

// Fetch payment records for the logged-in user
$sql = "SELECT id, dop, bank, file, status FROM payment WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barat Stock Trading</title>
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    

</head>
<body>
    <?php require "nav-bar.php"; ?>
    



    
<div class="container mb-5" style="margin-top:100px;">

<div class="row justify-content-center">


                    
    <div class="col-md-6 mb-5">
    <div class="row">
                    <div class="col text-center mb-2">
                        <h1 style="  text-shadow: 1px 1px 1px black, 3px 3px 5px black;">Check Payment Status</h1>
                    </div>
                </div>
                <div class="row">
                    <div class="col mb-3">
                    <a href="payment_add.php" class="add-admin btn btn-dark" style=" padding:10px;">Add New Payment</a>
                    </div>
                </div>

        <div class="row ">
            <div class="col">
                <table style="box-shadow: rgba(0, 0, 0, 0.56) 0px 22px 70px 4px; text-align:center;border-radius:10px;">
                    <thead style="border:1px solid gray; ">
                    <tr>
  <th scope="col" style="border:1px solid gray; padding:15px; width:180px;">Date</th>
  <th scope="col" style="border:1px solid gray; padding:15px; width:180px;">Bank</th>
  <th scope="col" style="border:1px solid gray; padding:15px; width:180px;">screenshot</th>
  <th scope="col" style="border:1px solid gray; padding:15px; width:180px;">status</th>
  <th scope="col" style="border:1px solid gray; padding:15px; width:180px;">Actions</th>
</tr>
                    </thead>
                    <tbody style="border:1px solid gray;">
                    <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                       
                        echo "<td>" . htmlspecialchars($row['dop']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['bank']) . "</td>";
                        echo "<td><a href='../upload/" . htmlspecialchars($row['file']) . "' target='_blank'>View Screenshot</a></td>";
                        echo "<td>" . htmlspecialchars($row['status']) . "</td>";
                        
                        // Allow edit and delete if status is 'pending' or 'rejected'
                        if ($row['status'] === 'pending' || $row['status'] === 'rejected') {
                            echo "<td><a href='payment_edit.php?id=" . htmlspecialchars($row['id']) . "'>Edit</a> | ";
                            echo "<a href='payment_delete.php?id=" . htmlspecialchars($row['id']) . "' onclick='return confirm(\"Are you sure you want to delete this payment?\");'>Delete</a></td>";
                        } else {
                            echo "<td>-</td>"; // No action available
                        }

                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>No payment records found.</td></tr>";
                }
                ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>




    <?php require "footer.php"; ?>
</body>
</html>
