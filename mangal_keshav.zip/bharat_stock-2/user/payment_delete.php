<?php
session_start();
require '../classes/Database.php';
require '../classes/User.php';

if (!isset($_SESSION['is_logged_in']) || !$_SESSION['is_logged_in']) {
    header('Location: ../logout.php');
    exit();
}

$database = new Database();
$conn = $database->connDb();

$user_id = $_SESSION['user_id'];
$payment_id = $_GET['id'] ?? null;

if (!$payment_id) {
    echo "Invalid payment ID.";
    exit();
}

// Verify that the payment belongs to the logged-in user
$stmt = $conn->prepare("SELECT file FROM payment WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $payment_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Payment not found or you do not have permission to delete this payment.";
    exit();
}

$payment = $result->fetch_assoc();

// Delete the file associated with the payment if it exists
if (!empty($payment['file'])) {
    $filePath = "../upload/" . $payment['file'];
    if (file_exists($filePath)) {
        unlink($filePath);  // Delete the file
    }
}

// Delete the payment record from the database
$stmt = $conn->prepare("DELETE FROM payment WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $payment_id, $user_id);

if ($stmt->execute()) {
    header('Location: payment.php?message=Payment deleted successfully');
    exit();
} else {
    echo "Error deleting payment: " . $stmt->error;
}

?>
