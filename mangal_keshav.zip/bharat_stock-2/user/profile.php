<?php
session_start();
require '../classes/Database.php';
require '../classes/User.php';

if (!isset($_SESSION['is_logged_in']) || !$_SESSION['is_logged_in']) {
    header('Location: ../logout.php');
    exit();
}

$database = new Database();
$conn = $database->connDb();

$user_id = $_SESSION['user_id'];
$activeuser = User::getById($conn, $user_id);  // Assuming this method fetches user data based on user ID
$userName = $activeuser['name'];
$userEmail = $activeuser['email'];
$userDob = $activeuser['dob'];
$userPhone = $activeuser['phone'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newName = $_POST['name'];
    $newDob = $_POST['dob'];
    $newPhone = $_POST['phone'];
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];

    $errors = [];

    if ($newPassword !== $confirmPassword) {
        $errors[] = "Passwords do not match. Please try again.";
    }

    if (empty($errors)) {
        $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);
        $stmt = $conn->prepare("UPDATE users SET name = ?, dob = ?, phone = ?, password = ? WHERE id = ?");
        $stmt->bind_param('ssssi', $newName, $newDob, $newPhone, $hashedPassword, $user_id);

        if ($stmt->execute()) {
            $successMessage = "Profile updated successfully.";
        } else {
            $errorMessage = "Failed to update profile. Please try again.";
        }

        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - Barat Stock Trading</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/js/all.min.js">
  
</head>
<body style="background:#fff;">


<?php require "nav-bar.php"; ?>

    
   <h1 style="text-align:center;margin-top:100px ;  text-shadow: 1px 1px 1px black, 5px 5px 7px black;">User Profile</h1>
    

      

    

<div class="container box-shadow " style="background:#fff;  border-radius:50px;   ">
                
         

                    <div class="row justify-content-center " >
                        <div class="col-md-4 p-4" style="border-radius:30px; border:1px solid black; margin-top:50px; margin-bottom:60px; box-shadow: rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px; ">
                            
                        <form action="" method="POST">
                        <div class="col mt-3 mb-3">
                        <label for="name">Name:</label>
                        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($userName); ?>" required  style="width:280px;">
  </div>
  <div class="mb-3">
    
  <label for="dob">Date of Birth:</label>
  <input type="date" id="dob" name="dob" value="<?php echo htmlspecialchars($userDob); ?>" required style="width:230px;">
 
  </div>
  <div class="mb-3">
  <label for="phone">Phone Number:</label>
  <input type="number" id="phone" name="phone" value="<?php echo htmlspecialchars($userPhone); ?>" required style="width:210px;">
  </div>
  <div class="mb-3">
  <label for="email">Email:</label>
  <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($userEmail); ?>" readonly style="width:280px;">
  </div>
  <div class="mb-3">
  <label for="new_password">New Password:</label>
                <input type="password" id="new_password" name="new_password" style="width:217px;">
  </div>
  <div class="mb-3">
  <label for="confirm_password">Confirm Password:</label>
  <input type="password" id="confirm_password" name="confirm_password">
  </div>
  

  <div class="form-group">
                <button type="submit" class="btn btn-dark" style="border-radius:10px;  box-shadow:2px 2px 5px 5px black;">Update Profile</button>
            </div>
</form>
<?php if (isset($successMessage)) { echo "<p style='color: green;'>$successMessage</p>"; } ?>
        <?php if (isset($errorMessage)) { echo "<p style='color: red;'>$errorMessage</p>"; } ?>
        <?php if (!empty($errors)) { foreach ($errors as $error) { echo "<p style='color: red;'>$error</p>"; } } ?>
                        </div>
                    </div>
                </div>
   

              

    <?php require "footer.php"; ?>
</body>
</html>
