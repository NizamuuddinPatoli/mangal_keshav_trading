<?php
session_start();
require '../classes/Database.php';
require '../classes/User.php';

if (!isset($_SESSION['is_logged_in']) || !$_SESSION['is_logged_in']) {
    header('Location: ../logout.php');
    exit();
}

$database = new Database();
$conn = $database->connDb();

$user_id = $_SESSION['user_id'];
$activeuser = User::getById($conn, $user_id);
$userName = $activeuser['name'];
$userEmail = $activeuser['email'];

$payment_id = $_GET['id'] ?? null;

if (!$payment_id) {
    echo "Payment ID is missing.";
    exit();
}

// Fetch payment details
$stmt = $conn->prepare("SELECT * FROM payment WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $payment_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "No payment found for this ID.";
    exit();
}

$payment = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dop = $_POST['dop'];
    $bank = $_POST['banks'];
    $file = $_FILES['file_upload'];
    $status = $payment['status'];

    // Validate inputs
    if (empty($dop) || empty($bank)) {
        echo "Date of Payment and Bank fields are required.";
    } else {
        // Handle file upload if a new file is provided
        if ($file['name']) {
            $targetDir = "../upload/";
            $fileName = basename($file["name"]);
            $targetFilePath = $targetDir . $fileName;
            $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

            // Allow only certain file formats
            $allowedTypes = ['jpg', 'png', 'jpeg', 'gif', 'pdf'];
            if (in_array($fileType, $allowedTypes)) {
                if (move_uploaded_file($file["tmp_name"], $targetFilePath)) {
                    // Update payment details with the new file
                    $stmt = $conn->prepare("UPDATE payment SET dop = ?, bank = ?, file = ? WHERE id = ? AND user_id = ?");
                    $stmt->bind_param("sssii", $dop, $bank, $fileName, $payment_id, $user_id);
                } else {
                    echo "Sorry, there was an error uploading your file.";
                    exit();
                }
            } else {
                echo "Sorry, only JPG, JPEG, PNG, GIF, & PDF files are allowed.";
                exit();
            }
        } else {
            // Update payment details without changing the file
            $stmt = $conn->prepare("UPDATE payment SET dop = ?, bank = ? WHERE id = ? AND user_id = ?");
            $stmt->bind_param("ssii", $dop, $bank, $payment_id, $user_id);
        }

        if ($stmt->execute()) {
            echo "Payment details updated successfully.";
            header('Location: payment.php');
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Payment</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/js/all.min.js">
    
  
</head>
<body>
    <?php require "nav-bar.php"; ?>
    
    
       
    <div class="container mb-5 mt-5">
    <div class="row justify-content-center " >
    <h1 style="text-align:center;">Edit Payment</h1>
                    <div class="col-md-4 p-4" style="border-radius:30px; border:1px solid black; margin-top:50px; margin-bottom:60px; box-shadow: rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px; ">
                        
                    <form action="" method="POST" enctype="multipart/form-data">
                    <div class="col mt-3 mb-3">
                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($userName); ?>" readonly style="width:280px;">
</div>
<div class="mb-3">
<label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($userEmail); ?>" readonly style="width:283px;">

</div>
<div class="mb-3">
<label for="dop">Date of Payment:</label>
<input type="date" id="dop" name="dop" value="<?php echo htmlspecialchars($payment['dop']); ?>" required style="width:204px;">
</div>
<div class="mb-3">
<label for="bank">Bank:</label>
                <select id="banks" name="banks" required style="width:286px;">
                    <option value="Airtel Payments Bank" <?php echo $payment['bank'] == 'Airtel Payments Bank' ? 'selected' : ''; ?>>Airtel Payments Bank</option>
                    <option value="India Post Payments Bank" <?php echo $payment['bank'] == 'India Post Payments Bank' ? 'selected' : ''; ?>>India Post Payments Bank</option>
                    <option value="Paytm Payments Bank" <?php echo $payment['bank'] == 'Paytm Payments Bank' ? 'selected' : ''; ?>>Paytm Payments Bank</option>
                    <option value="State Bank of India" <?php echo $payment['bank'] == 'State Bank of India' ? 'selected' : ''; ?>>State Bank of India</option>
                    <option value="HDFC Bank" <?php echo $payment['bank'] == 'HDFC Bank' ? 'selected' : ''; ?>>HDFC Bank</option>
                    <option value="ICICI Bank" <?php echo $payment['bank'] == 'ICICI Bank' ? 'selected' : ''; ?>>ICICI Bank</option>
                    <option value="Axis Bank" <?php echo $payment['bank'] == 'Axis Bank' ? 'selected' : ''; ?>>Axis Bank</option>
                    <option value="other" <?php echo $payment['bank'] == 'other' ? 'selected' : ''; ?>>Other</option>
                </select>
</div>
<div class="mb-3">
<label for="fileUpload">Payment Screenshot</label>
                <input type="file" id="fileUpload" name="file_upload">
                                <?php if ($payment['file']) : ?>
                    <p>Current file: <a href="../upload/<?php echo htmlspecialchars($payment['file']); ?>" target="_blank" style="text-decoration:none; color:red;">View</a></p>
                <?php endif; ?>
</div>
<div class="mb-3">

</div>


<div class="form-group">
            <button type="submit" class="btn btn-dark" style="border-radius:10px;  box-shadow:2px 2px 5px 5px black;">Update payment</button>
        </div>
</form>

                    </div>
                </div>
    </div>
    

</body>
</html>

