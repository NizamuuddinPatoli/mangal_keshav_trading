<?php
session_start();
require '../classes/Database.php';
require '../classes/Demat.php';

if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'demat') {
    header('Location: ../logout.php');
    exit();
}

$database = new Database();
$conn = $database->connDb();

$user_id = $_SESSION['user_id'];

// Fetch data from the demat table
$stmt = $conn->prepare("SELECT name, email, password, phone, gender, pan, dob, adhar_no, file FROM demat WHERE id = ?");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();
$dematData = $result->fetch_assoc();

// Fetch data from the doc table
$stmt2 = $conn->prepare("SELECT file, sign FROM doc WHERE email = (SELECT email FROM demat WHERE id = ?)");
$stmt2->bind_param('i', $user_id);
$stmt2->execute();
$result2 = $stmt2->get_result();
$docData = $result2->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];
    $errors = [];

    if ($newPassword !== $confirmPassword) {
        $errors[] = "Passwords do not match. Please try again.";
    }

    if (empty($errors)) {
        $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);
        $stmt = $conn->prepare("UPDATE demat SET password = ? WHERE id = ?");
        $stmt->bind_param('si', $hashedPassword, $user_id);

        if ($stmt->execute()) {
            $successMessage = "Password updated successfully.";
        } else {
            $errorMessage = "Failed to update password. Please try again.";
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - Barat Stock Trading</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/js/all.min.js">

</head>
<body>
    <?php require "nav-bar.php"; ?>


    
<div class="container box-shadow " style="background:#fff;  border-radius:50px;   ">
                  <h1 class="text-center " style="margin-top:30px; text-shadow: 1px 1px 1px black, 5px 5px 7px black;">User Profile</h1>
         

                    <div class="row justify-content-center " >
                        <div class="col-md-5 p-4" style="border-radius:30px; border:1px solid black; margin-top:50px; margin-bottom:60px; box-shadow: rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px; ">
                        <form action="" method="POST">
                        <div class="col">
                        <label for="name">Name:</label>
                        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($dematData['name']); ?>" readonly style="width:369px; margin-bottom:10px;">
  <div class="mb-3">
  <label for="dob">Date of Birth:</label>
  <input type="date" id="dob" name="dob" value="<?php echo htmlspecialchars($dematData['dob']); ?>" readonly style="width:320px;">
  </div>
  <div class="mb-3">
  <label for="phone">Phone Number:</label>
  <input type="number" id="phone" name="phone" value="<?php echo htmlspecialchars($dematData['phone']); ?>" readonly style="width:300px;">
  </div>
  <div class="mb-3">
  <label for="email">Email:</label>
  <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($dematData['email']); ?>" readonly style="width:370px;">
  </div>
  <div class="mb-3">
  <label for="gender">Gender:</label>
                <input type="text" id="gender" name="gender" value="<?php echo htmlspecialchars($dematData['gender']); ?>" readonly style="width:360px;">
  </div>
  <div class="mb-3">
  <label for="pan">PAN:</label>
                <input type="text" id="pan" name="pan" value="<?php echo htmlspecialchars($dematData['pan']); ?>" readonly style="width:380px;">
  </div>
  <div class="mb-3">
  <label for="adhar_no">Adhar Number:</label>
  <input type="text" id="adhar_no" name="adhar_no" value="<?php echo htmlspecialchars($dematData['adhar_no']); ?>" readonly style="width:304px;">
  </div>
  <div class="mb-3">
  <label for="new_password">New Password:</label>
  <input type="password" id="new_password" name="new_password" style="width:304px;">
  </div>
  <div class="mb-3">
  <label for="confirm_password">Confirm Password:</label>
  <input type="password" id="confirm_password" name="confirm_password" style="width:284px;">
  </div>
  

  <div class="form-group">
                <button type="submit" class="btn btn-dark" style="border-radius:10px;  box-shadow:2px 2px 5px 5px black;">Update Password</button>
            </div>
</form>
                        </div>
                    </div>
                </div>

                

                
<div class="container box-shadow " style="background:#fff;  border-radius:50px;   ">
                  <h1 class="text-center " style="margin-top:30px; text-shadow: 1px 1px 1px black, 5px 5px 7px black;">Document Information</h1>
                    
      
                    <div class="row justify-content-center " >
                        <div class="col-md-5 p-4" style="border-radius:30px; border:1px solid black; margin-top:50px; margin-bottom:60px; box-shadow: rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px; ">
                        <form action="profile.php" method="POST">
                       
  <div class="mb-3">
  <label>Uploaded Document:</label>
  <a href="../uploads_doc/<?php echo htmlspecialchars($docData['file']); ?>" target="_blank" style="text-decoration:none; color:maroon;">View Document</a>
  </div>
  <div class="mb-3">
  <label>Digital Signature:</label>
                <a href="../uploads_doc/<?php echo htmlspecialchars($docData['sign']); ?>" target="_blank" style="text-decoration:none; color:maroon;">View Signature</a>
            </div>
  </div>
  
  </div>
  

  
</form>
<?php if (isset($successMessage)) { echo "<p style='color: green;'>$successMessage</p>"; } ?>
        <?php if (isset($errorMessage)) { echo "<p style='color: red;'>$errorMessage</p>"; } ?>
        <?php if (!empty($errors)) { foreach ($errors as $error) { echo "<p style='color: red;'>$error</p>"; } } ?>
                        </div>
                    </div>
                </div>

    <?php require "footer.php"; ?>
</body>
</html>