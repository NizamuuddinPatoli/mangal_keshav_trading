<?php
require '../classes/Database.php';

$error = "";
$msg = "";

if (isset($_GET['email'])) {
    $email = $_GET['email'];

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['document']) && isset($_FILES['signature']) && isset($_POST['terms'])) {
        $database = new Database();
        $conn = $database->connDb();

        // Directory where files will be uploaded
        $targetDir = "../uploads_doc/";

        // Document upload
        $docFileName = basename($_FILES["document"]["name"]);
        $docFilePath = $targetDir . $docFileName;
        $docFileType = pathinfo($docFilePath, PATHINFO_EXTENSION);

        // Signature upload
        $signFileName = basename($_FILES["signature"]["name"]);
        $signFilePath = $targetDir . $signFileName;
        $signFileType = pathinfo($signFilePath, PATHINFO_EXTENSION);

        // Allowed file types
        $allowedTypes = array('jpg', 'png', 'jpeg', 'gif', 'pdf');

        // Check if the directory exists and is writable
        if (!is_dir($targetDir) || !is_writable($targetDir)) {
            $error = "Upload directory does not exist or is not writable.";
        } else if (in_array($docFileType, $allowedTypes) && in_array($signFileType, $allowedTypes)) {
            // Move uploaded files to the server
            if (move_uploaded_file($_FILES["document"]["tmp_name"], $docFilePath) && move_uploaded_file($_FILES["signature"]["tmp_name"], $signFilePath)) {
                
                // Check if the email already exists in the `doc` table
                $query = "SELECT `id` FROM `doc` WHERE `email` = ?";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("s", $email);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    // Update existing record
                    $updateQuery = "UPDATE `doc` SET `file` = ?, `sign` = ? WHERE `email` = ?";
                    $updateStmt = $conn->prepare($updateQuery);
                    $updateStmt->bind_param("sss", $docFileName, $signFileName, $email);
                    if ($updateStmt->execute()) {
                        $msg = "Document and signature updated successfully.";
                    } else {
                        $error = "Failed to update document and signature.";
                    }
                } else {
                    // Insert new record
                    $insertQuery = "INSERT INTO `doc` (`email`, `file`, `sign`) VALUES (?, ?, ?)";
                    $insertStmt = $conn->prepare($insertQuery);
                    $insertStmt->bind_param("sss", $email, $docFileName, $signFileName);
                    if ($insertStmt->execute()) {
                        $msg = "Document and signature uploaded successfully.";
                        header("Location: foam.php?email=" . urlencode($email));
                        exit(); // Always exit after a redirect to prevent further code execution
                    } else {
                        $error = "Failed to upload document and signature.";
                    }
                }

            } else {
                $error = "Error uploading files.";
            }
        } else {
            $error = "Invalid file format. Only JPG, JPEG, PNG, GIF, and PDF files are allowed.";
        }
    } else {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $error = "Please accept the terms and conditions and upload both document and signature.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Document and Signature</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/js/all.min.js">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
        }

        h2 {
            text-align: center;
            color: maroon;
        }

        label {
            font-weight: bold;
            color: #333;
            text-align: center;
            margin-bottom: 5px;
        }

        input[type="file"], input[type="checkbox"] {
            margin-bottom: 15px;
            display: block;
        }

        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            width: 100%;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #45a049;
        }

        p {
            text-align: center;
            color: #d9534f; /* Error color */
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Upload Document and Digital Signature</h2>

        <!-- Display any server-side messages -->
        <p><?php echo !empty($msg) ? $msg : $error; ?></p>

        <form action="" method="POST" enctype="multipart/form-data">
            <label for="document">Upload Document:</label>
            <input type="file" name="document" id="document" required>

            <label for="signature">Upload Digital Signature:</label>
            <input type="file" name="signature" id="signature" required>

            <input type="checkbox" name="terms" id="terms" required>
            <label for="terms">I accept the terms and conditions.</label><br>

            <button type="submit" class="btn btn-dark">Submit</button>
        </form>
    </div>
</body>
</html>
