<?php
$database = new Database();
$conn = $database->connDb();

$user_id = $_SESSION['user_id']; // Ensure the session contains a valid user_id
$activeuser = Demat::getById($conn, $user_id);

// Check if user data was retrieved
if ($activeuser) {
    $userName = $activeuser['name']; // Access name only if data exists
} else {
    $userName = "Guest"; // Fallback if no user data is found
}

?>
<head>
        
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/js/all.min.js">
</head>
<header>
    
<div class="nav" style="box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;">
    

    <div class="container"  >
        <div class="row">
            <div class="col-md-2">
                <div class="row">
                    <div class="col">
                    <img src="../image/MAngal-KEshav-logo.png" class="card-img-top" alt="..." style="overflow-clip-margin: content-box;
        overflow: clip;vertical-align: middle;
        border-style: none;max-width: 100%;
        height: auto;margin: 0;    max-height: 150px;padding: 5px 0px;
            position: relative;
            top: unset;">
                    </div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="row">
                    <div class="col">
                    <ul class="nav">
                        <li class="nav-item">
            
            <?php if ($userName): ?>
        <li class="hide-on-small" style="color:maroon; margin-top:20px;font-size:20px; text-align:center; ">Welcome,  <?= htmlspecialchars($userName) ?></li>
        
    <?php else: ?>
        <li class="hide-on-small"><a href="signup.php">Signup</a></li>
    <?php endif; ?>
    
    </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-5 mt-3">
                <div class="row">
                    <div class="col">
                    <ul class="nav">
                <li class="nav-item">
                <a class="nav-link active " aria-current="page" href="profile.php" style="color: #5c768d;padding: 8px 18px;
    line-height: unset;display: inline-block; font-weight:bold;  margin-left:22px;">Profile</a>
                </li>
           
    
           
          
            <li class="nav-item">
            <a class="nav-link" href="dashboard.php " style="color: #5c768d;padding: 8px 18px;
        line-height: unset;display: inline-block; font-weight:bold; ">Home</a>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="payment.php " style="color: #5c768d;padding: 8px 18px;
        line-height: unset;display: inline-block;font-weight:bold; ">Payment Check</a>
            </li>
           
            
    
      
    </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-1 mt-3">
                <div class="row">
                    <div class="col">
                    <form class="d-flex" role="search">
        <a href="../logout.php" type="button" class="btn btn-outline-danger" style="margin-top: 5px;">Logout</a>
        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
     
    
    
    
    </div>
    
</header>