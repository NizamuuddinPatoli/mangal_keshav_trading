
<?php
session_start();
require '../classes/Database.php';
require '../classes/Demat.php';

// Check if the user is logged in and is of the correct type
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'demat') {
    header('Location: ../logout.php');
    exit();
}

// Initialize database connection
$database = new Database();
$conn = $database->connDb();

// Retrieve user ID from session
$user_id = $_SESSION['user_id'];
// Retrieve the user data using the Demat class
$activeuser = Demat::getById($conn, $user_id);

// Ensure the user data was retrieved
if ($activeuser) {
    $userName = $activeuser['name']; // Get the user's name
} 

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barat Stock Trading</title>
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/js/all.min.js">
</head>
<body>
<?php require "nav-bar.php"; ?>
                





                <div id="carouselExampleCaptions" class="carousel slide">
                        <div class="carousel-indicators">
                          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
                          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
                        </div>
                        <div class="carousel-inner">
                          <div class="carousel-item active">
                            <img src="../image/OIP-5.jpeg" class="d-block w-100" alt="..." style="height: 350px ; opacity: 0.7;  ">
                            <div class="carousel-caption d-none d-md-block"  style="position: absolute; width: 50%; top: 2%; left: 0; margin-left: 15%; text-align: left;">
                              <h2  style="font-size: 5em; color: #000;
                              font-size: 30px;
                              font-weight: 600;color: #000;
                  font-size: 30px;
                  font-weight: 600;display: block;
                  text-align: left;
                  margin-block-start: 0.83em;
                  margin-block-end: 0.83em;
                  margin-inline-start: 0px;
                  margin-inline-end: 0px;
                  
                  unicode-bidi: isolate;" >India’s Leading Stock Broking Company</h2>
                              <p  style="color: #B30001;
                              font-size: 25px;
                              font-weight: 400;animation-delay: 0.4s;width: 80%;
                                " >Nurturing Wealth since 1939</p>
                           
                            </div>
                          </div>
                          <div class="carousel-item">
                            <img src="../image/istockphoto-499195831-612x612.jpg" class="d-block w-100" alt="..." style="height: 350px;  opacity:0.6;">
                            <div class="carousel-caption d-none d-md-block"  style="position: absolute; width: 50%; top: 2%; left: 0; margin-left: 15%; text-align: left;">
                              <h2   style="font-size: 5em; color: #000;
                              font-size: 30px;
                              font-weight: 600;color: #000;
                  font-size: 30px;
                  font-weight: 600;display: block;
                  text-align: left;
                  margin-block-start: 0.83em;
                  margin-block-end: 0.83em;
                  margin-inline-start: 0px;
                  margin-inline-end: 0px;
                  
                  unicode-bidi: isolate;" >Mangal Keshav Investment Advisory Services</h2>
                              <p  style="color: #B30001;
                              font-size: 25px;
                              font-weight: 400;animation-delay: 0.4s;width: 80%;
                                "  >SEBI Registered</p>
                
                <button type="button" class="btn btn-outline-success" style="background-image: linear-gradient(#B30001, #660000);
                font-size: 18px;
                padding: 14px 20px;
                margin-left: 0px;font-weight: 500;
                letter-spacing: 1px;
                display: inline-block; border-radius: 5px;
                transition: 0.5s;
                line-height: 1;
                margin: 10px;
                color: #fff;                ">Learn More</button>
                            </div>
                          </div>
                        
                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                          <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                          <span class="carousel-control-next-icon" aria-hidden="true"></span>
                          <span class="visually-hidden">Next</span>
                        </button>
                      </div>
                
                
                
                      <div class="container mt-5  mb-5">
                        <div class="row">
                          <div class="col-md-5">
                            <div class="row">
                              <div class="col" >
                                <h2 style="font-weight: 700; 
                                margin-bottom: 50px;
                                padding-bottom: 0;
                                color: #363636; font-size: 34px;">Reasons to choose <span style="color: #B30001;"> Mangal Keshav </span></h2>
                              </div>
                            </div>
                            <div class="row">
                              <div class="col">
                                
                                <p>
                                  <i class="fa-solid fa-check-double" style="color: #B30001;"></i>
                                  Member of stock exchanges since 1939</p>
                              </div>
                            </div>
                            <div class="row">
                              <div class="col">
                                <p>  <i class="fa-solid fa-check-double" style="color: #B30001;"></i> Our service is based on high level of professionalism and integrity</p>
                              </div>
                            </div>
                            <div class="row">
                              <div class="col">
                                <p>  <i class="fa-solid fa-check-double" style="color: #B30001;"></i> We believe in personal investment management, thus offer you a tailor-made investment solution</p>
                              </div>
                            </div>
                            <div class="row">
                              <div class="col">
                                <p>  <i class="fa-solid fa-check-double" style="color: #B30001;"></i> Our core values revolve around client investment needs and objectives</p>
                              </div>
                            </div>
                            <div class="row">
                              <div class="col">
                                <p>  <i class="fa-solid fa-check-double" style="color: #B30001;"></i> We offer competitive and transparent fee structure</p>
                              </div>
                            </div>
                            <div class="row">
                              <div class="col">
                                <p>  <i class="fa-solid fa-check-double" style="color: #B30001;"></i>  Our services portfolio offers wide range of products for your wealth creation</p>
                              </div>
                            </div>
                          </div>
                          <div class="col-md-6">
                
                            <div class="row">
                              <div class="col">
                                <div class="row" >
                                  <div class="col">
                                    <img src="../image/R (3).png" class="card-img-top" alt="...">
                                    
                
                                  </div>
                                </div>
                               
                              </div>
                            </div>
                            <div class="row"></div>
                            <div class="row"></div>
                          </div>
                        </div>
                      </div>
                
                
                
                      <div class="container  ">
                        <div class="row">
                          <div class="col-md-12 text-center">
                            <div class="row">
                              <div class="col">
                                <small style="background-color: #B30001; color: #fff;  padding: 30px; border-radius: 7px; font-size: 25px;"> <i class="fa-solid fa-coins" ></i> Products
                                
                                </small>
                                <small style="background-color: #fff; color: #B30001; border: 2px solid #B30001 ;  padding: 25px; font-size: 24px; border-bottom-right-radius: 25px; border-top-right-radius: 25px;">
                                  <i class="fa-regular fa-clock" style="color: #B30001;"></i>  Services
                                </small>
                                
                              </div>
                             
                            </div>
                          </div>
                        </div>
                      </div>
                
                
                      <div class="container-fluid pb-5 pt-5 " style="    background: #F8F8F8;">
                        <div class="row">
                          <div class="col-md-3 border-right mb-2" style="border-right: 1px solid #dee2e6 !important; padding-left: 50px; ">
                            <div class="row mb-3 mt-5" >
                              <div class="col " >
                                <a href="" style="color: #B30001; font-size: 20px;text-decoration: none;
                    background-color: transparent;">
                                  <i class="fa-solid fa-caret-right" style="color: #B30001;"></i>
                                  Equity Trading
                                </a>
                              </div>
                            </div>
                            <div class="row mb-3">
                              <div class="col " >
                                <a href="" style="color: #707070;
                    font-size: 20px;text-decoration: none;
                    background-color: transparent;">
                                  <i class="fa-solid fa-caret-right" style="color: #707070;
                "></i>
                                  Commodity Trading
                                </a>
                              </div>
                            </div>
                            <div class="row mb-3">
                              <div class="col"></div>
                                <a href="" style="color: #707070;
                    font-size: 20px;text-decoration: none;
                    background-color: transparent;">
                                  <i class="fa-solid fa-caret-right" style="color: #707070;
                "></i>
                                  Currency Trading
                                </a>
                              </div>
                              <div class="row mb-3">
                                <div class="col"></div>
                                  <a href="" style="color: #707070;
                      font-size: 20px;text-decoration: none;
                      background-color: transparent;">
                                    <i class="fa-solid fa-caret-right" style="color: #707070;
                  "></i>
                                    Derivatives Trading
                                  </a>
                                </div>
                            </div>
                
                            <div class="col-md-4 mt-5 " style="padding-left: 50px;">
                              <div class="row">
                                <div class="col">
                                  <ul class="list-height" >
                                    <li>
                                      Well researched equity recommendations
                                    </li>
                                    <li>Risk based investment products</li>
                                    <li>Tailormade products for investors and traders</li>
                                    <li>Seamless back-office support.</li>
                                    <li>Intra-day and long-term recommendations.</li>
                                    <li>Market reports.</li>
                                    <a href="" class="btn btn-dark" style="color: #fff;
                                    background-color: #343a40;
                                    border-color: #343a40;">Equity Trading</a>
                                  </ul>
                                  
                                </div>
                              </div>
                            </div>
                            <div class="col-md-4 mt-5">
                              <div class="row">
                                <div class="col">
                                  <img src="../image/p1.png" class="card-img-top" alt="...">
                
                                </div>
                              </div>
                            </div>
                
                            </div>
                          </div>
                
                
                
                          <div class="container mt-5 mb-5">
                              <div class="row">
                                <div class="col-md-12 text-center">
                                     <h2>Research  
                                      <span style="    color: #B30001;"> Reports </span>
                                     </h2>
                                </div>
                              </div>
                          </div>
                
                
                      
                
                
                
                          <div class="container-fluid mt-5 mb-5">
                            <div class="row justify-content-evenly">
                              <div class="col-md-4">
                                <div class="row">
                                  <div class="col"> <i class="fa-solid fa-radio" style="color: #B30001; font-size: 50px;" ></i></div>
                                </div>
                                <div class="row">
                                  <div class="col">
                                    <h3 style="font-size: 40px;color: #444;">Fundamental 
                                      <br> Reports
                                    </h3>
                                  </div>
                                </div>
                                <div class="row">
                                  <div class="col">
                                    <a href="" style="color: #B30001; text-decoration: none;
                    background-color: transparent;">  <i class="fa-solid fa-caret-right" style="color: #B30001;"></i> Company Reports</a>
                                  </div>
                                </div>
                                <div class="row">
                                  <div class="col">
                                    <a href="" style="color: #B30001; text-decoration: none;
                    background-color: transparent;">  <i class="fa-solid fa-caret-right" style="color: #B30001;"></i> Special Reports</a>
                                  </div>
                                </div>
                              </div>
                              <div class="col-md-4">
                                <img src="../image/fundamental_reports.png" alt="" style="position: relative; height: 300px; position: absolute;">
                                <div class="row">
                                  <div class="col">
                                    <ul class="pb-5 pt-3 pl-3" style="box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px ; position:relative; background-color: #fff; border-radius: 50px; ">
                                      <li>
                                        Team of Highly qualified & professional Research analysts
                                      </li>
                                      <li>In-depth fundamental research reports</li>
                                      <li>Micro to Macro economic monitoring</li>
                                      <li>Robust Analytical services</li>
                                      <li>Short term – long term research picks</li>
                                      <li>Highest coverage of stocks</li>
                                      <li> Market analysis and outlook</li>
                                    </ul>
                                  </div>
                                </div>
                
                              </div>
                            </div>
                          </div>
                          </div>
                
                
                
                
                
                          <div class="container-fluid mb-5 mt-5">
                            <div class="row justify-content-evenly">
                              <div class="col-md-4">
                                <img src="../image/technical_report.png" alt="" style="position: relative; height: 300px; position: absolute;">
                
                                <div class="row">
                                  <div class="col">
                                    <ul class=" pt-5 pb-5" style="box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px; border-radius: 20px; position:relative; background-color: #fff; border-radius: 50px;">
                                      <li>Team of Highly qualified & professional Research analysts</li>
                                      <li>In-depth fundamental research reports</li>
                                      <li>Micro to Macro economic monitoring</li>
                                      <li>Robust Analytical services</li>
                                      <li>Short term – long term research picks</li>
                                      <li>Highest coverage of stocks</li>
                                      <li>Market analysis and outlook</li>
                                    </ul>
                                  </div>
                                </div>
                              </div>
                              <div class="col-md-4">
                                <div class="row">
                                  <div class="col">
                                    <i class="fa-solid fa-radio" style="color: #B30001; font-size: 50px;" ></i>
                                  </div>
                                </div>
                                <div class="row">
                                  <div class="col">
                                    <h3 style="font-size: 40px;color: #444;">Technical
                                      <br> Reports
                                    </h3>
                                </div>
                                <div class="row">
                                  <div class="col"></div>
                                    <a href="" style="color: #B30001; text-decoration: none;
                    background-color: transparent;">  <i class="fa-solid fa-caret-right" style="color: #B30001;"></i> Daily Report</a>
                                   </div>
                                </div>
                                <div class="row">
                                  <div class="col">
                                    <a href="" style="color: #B30001; text-decoration: none;
                    background-color: transparent;">  <i class="fa-solid fa-caret-right" style="color: #B30001;"></i> Top Picks</a>
                                  </div>
                                </div>
                                <div class="row">
                                  <div class="col">
                                    <a href="" style="color: #B30001; text-decoration: none;
                    background-color: transparent;">  <i class="fa-solid fa-caret-right" style="color: #B30001;"></i> Weekly Report</a>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          
                          </div>
                
                
                
                
                
                
                          <div class="container-fluid mt-5 mb-5">
                            <div class="row justify-content-evenly">
                              <div class="col-md-4 mt-5">
                                <div class="row">
                                  <div class="col">
                                    <i class="fa-solid fa-radio" style="color: #B30001; font-size: 50px;" ></i>
                                  </div>
                                </div>
                                <div class="row">
                                  <div class="col">
                                    <h3 style="font-size: 45px;margin-bottom: .5rem;
                                    font-weight: 500;
                                  color: #444;">Knowledge Panel</h3>
                                  </div>
                                </div>
                                <div class="row">
                                  <div class="col">
                                    <a href="" style="color: #B30001; text-decoration: none;
                    background-color: transparent;">  <i class="fa-solid fa-caret-right" style="color: #B30001;"></i> Dermat Account</a>
                                  </div>
                                </div>
                                <div class="row">
                                  <div class="col">
                                    <a href="" style="color: #B30001; text-decoration: none;
                    background-color: transparent;">  <i class="fa-solid fa-caret-right" style="color: #B30001;"></i> Trading Account</a>
                                  </div>
                                </div>
                                <div class="row">
                                  <div class="col">
                                    <a href="" style="color: #B30001; text-decoration: none;
                    background-color: transparent;">  <i class="fa-solid fa-caret-right" style="color: #B30001;"></i> Online share Trading</a>
                                  </div>
                                </div>
                                <div class="row">
                                  <div class="col">
                                    <a href="" style="color: #B30001; text-decoration: none;
                    background-color: transparent;">  <i class="fa-solid fa-caret-right" style="color: #B30001;"></i> Intraday Trading</a>
                                  </div>      
                                </div>
                              </div>
                              <div class="col-md-4">
                                <img src="../image/Knowledge-Panel-bak.png" class="card-img-top" alt="..." >
                              </div>
                            </div>
                          </div>
                
                
                
                          <div class="container mt-5 mb-5">
                            <div class="row">
                              <div class="col-md-12 text-center">
                                <div class="row">
                                  <div class="col">
                                    <h2 style="    color: #363636; font-weight: 600">What Client are Saying <span style="color: #B30001;"> About Us  </span></h2>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                
                
                
                          <div class="container">
                
                          </div>
                
                
                          <div class="container mt-5 mb-5">
                            <div class="row">
                              <div class="col-md-12 text-center">
                                <div class="row">
                                  <div class="col">
                                    <h2 style="color: #B30001;">Blogs</h2>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                
                
                
                        
                <div class="container">
                  
                
                  <div id="carouselExample" class="carousel slide">
                    <div class="carousel-inner">
                      <div class="carousel-item active d-flex">
                        <div class="col-md-4">
                          <div class="card" style="width: 18rem;">
                            <img src="../image/fundamental_reports.png" class="card-img-top" alt="...">
                            <div class="card-body">
                              <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="card" style="width: 18rem;">
                            <img src="../image/th.jpeg" class="card-img-top" alt="...">
                            <div class="card-body">
                              <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="card" style="width: 18rem;">
                            <img src="../image/technical_report.png" class="card-img-top" alt="...">
                            <div class="card-body">
                              <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="carousel-item d-flex">
                        <div class="col-md-4">
                          <div class="card" style="width: 18rem;">
                            <img src="../image/Knowledge-Panel-bak.png" class="card-img-top" alt="...">
                            <div class="card-body">
                              <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-4">
                          <div class="card" style="width: 18rem;">
                            <img src="../image/fundamental_reports.png" class="card-img-top" alt="...">
                            <div class="card-body">
                              <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                            </div>
                          </div>
                        </div>
                
                
                
                
                      </div>
                    
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                      <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                      <span class="carousel-control-next-icon" aria-hidden="true"></span>
                      <span class="visually-hidden">Next</span>
                    </button>
                  </div>
                </div>
                
                
                
                
                <?php require "footer.php"; ?>
                

<script src="../script.js"></script>
</body>
</html>
