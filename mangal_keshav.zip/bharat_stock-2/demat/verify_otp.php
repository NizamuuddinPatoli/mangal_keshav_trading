<?php
require "../classes/Database.php";
require "../classes/Demat.php";
require '../smtp/PHPMailerAutoload.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $otp = $_POST['otp'];

    $database = new Database();
    $conn = $database->connDb();

    $userData = Demat::verifyOTP($conn, $email, $otp);

    if ($userData) {
        // Redirect to the password reset form
        header('Location: reset_password.php?email=' . $email . '&token=' . $userData['token']);
        exit;
    } else {
        echo 'Invalid OTP. Please try again.';
    }
}


?>

<section class="login-section">
        <div class="login-card">
        <div class="login-icon"><i class="fa fa-user text-light fa-3x"></i></div>
          
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify OTP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/js/all.min.js">
</head>
   <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            flex-direction: column;
            align-items: center;
            margin: 0;
            padding: 0;
        }
        .logo-container {
            margin-top: 20px;
        }
        .logo {
            width: 150px;
            height: auto;
        }
        h2 {
            color: #333;
        }
        form {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
            margin: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        input[type="email"],
        input[type="text"],
        input[type="password"] {
            width: calc(100% - 22px);
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-bottom: 12px;
        }
        button {
            background-color: #28a745;
            color: #fff;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #218838;
        }
        .error {
            color: #ff0000;
            margin-bottom: 10px;
        }
         .image-content {
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 20px;
        }
        .shape-container {
            display: flex;
            align-items: center;
            max-width: 800px;
            width: 100%;
        }
        .square {
            width: 150px;
            height: 150px;
            overflow: hidden;
            border-radius: 8px;
            margin-right: 20px;
        }
        .square img {
            width: 100%;
            height: auto;
        }
        .content {
            max-width: 500px;
        }
        .content h3 {
            margin-top: 0;
            color: #333;
        }
        .content p {
            color: #555;
        }
      footer {
            margin: 20px;
            color: #777;
        }
         .close-button {
            position: absolute;
            top: 20px;
            right: 20px;
            font-size: 24px;
            font-weight: bold;
            text-decoration: none;
            color: #333;
            background-color: #f5f5f5;
            padding: 10px;
            border-radius: 50%;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        .close-button:hover {
            background-color: #4CAF50; /* Green */
            color: white;
        }

        .close-button:focus {
            outline: none;
        }

    </style>
<body>
<div class="logo-container">
<img src="../image/MAngal-KEshav-logo.png" class="rounded mx-auto d-block" alt="...">
    
    <h2 style="text-align:center;">Verify OTP</h2>
   <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="row">
                <div class="col">
                <form method="post" action="">
        <input type="hidden" name="email" value="<?php echo htmlspecialchars($_GET['email']); ?>">
        <label for="otp">Enter OTP:</label>
        <input type="text" name="otp" required>
        <button type="submit" class="btn btn-dark" >Verify OTP</button>
    </form>
                </div>
            </div>
        </div>
    </div>
   </div>

</body>
</div>
</div>


<div class="container-fluid mt-5 pt-5 pb-5" style="background: #222222; color:#fff;
    ">
  <div class="row">
    <div class="col-md-3">
      <div class="row">
        <div class="col">
          <img src="../image/MAngal-KEshav-logo.png" class="card-img-top mb-2" alt="..." style="height: 150px; width:160px; padding: 8px;
          background: #fff;
          border-radius: 10px;">
        </div>
      </div>
      <div class="row">
        <div class="col">
          <button type="button" class="btn btn-outline-danger" style="    color: #fff; border-color: #B30001;">Open an Account</button>
        </div>
      </div>
      <div class="row">
        <div class="col"><i class="fa-brands fa-facebook" style="color: #bcbcbc; width: 36px;
    height: 36px; "></i>
          <i class="fa-brands fa-twitter" style="color: #bcbcbc; width: 36px;
    height: 36px;"></i>
          <i class="fa-brands fa-linkedin-in" style="color: #bcbcbc; width: 36px;
    height: 36px;"></i>
          <i class="fa-brands fa-youtube" style="color: #bcbcbc; width: 36px;
    height: 36px;"></i>
        </div>
        
      </div>
      <div class="row">
        <div class="col">
          <p style="font-size: 12px;
          color: #fff;
          opacity: .7;
      ">Mangal Keshav Financial Services LLP (www.mangalkeshav.com) has the sole and exclusive rights to own and operate the brand MKFSLP and MKSL in India.</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <img src="../image/attention-investors.jpg" class="card-img-top" alt="..." style="height: 150px; width:250px;">
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="row">
        <div class="col">
          <h4 style="font-size: 18px;
          color: #fff;
          font-weight: 600;
          opacity: .8;
          text-transform: capitalize;">Company</h4>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> Home</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right"  style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> About us</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> Careers</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> Contact us</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> Sub broker</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i>Fundamental Reports </small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style=" font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> Technical Reports</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> Blogs </small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> Media</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small  style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i>Videos</small>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="row">
        <div class="col">
          <h4 style="font-size: 18px;
          color: #fff;
          font-weight: 600;
          opacity: .8;
          text-transform: capitalize;">Services</h4>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> Demat Account</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> Trading Account</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> Alternate Investment Funds</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> NRI services</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> ipo services</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> Institutional trading</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> investment advisory </small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> mutual funds</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> portfolio management  services</small>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="row">
        <div class="col">
          <h4 style="font-size: 18px;
          color: #fff;
          font-weight: 600;
          opacity: .8;
          text-transform: capitalize;">Products</h4>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> equity trading </small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> commodity trading</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> derivative</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> currency trading</small>
        </div>
      </div>
      
        
        <div class="row">
          <div class="col">
            <h4 style="font-size: 18px;
            color: #fff;
            font-weight: 600;
            opacity: .8;
            text-transform: capitalize;">Knowledge plan</h4>
          </div>
        </div>
        <div class="row">
          <div class="col">
            <small style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
              opacity: .6;
              color: #fff;
              transition: all .2s;"></i> Demat account</small>
          </div>
        </div>
        <div class="row">
          <div class="col">
            <small style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
              opacity: .6;
              color: #fff;
              transition: all .2s;"></i> trading account</small>
          </div>
        </div>
        <div class="row">
          <div class="col">
            <small style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
              opacity: .6;
              color: #fff;
              transition: all .2s;"></i> online share trading </small>
          </div>
        </div>
        <div class="row">
          <div class="col">
            <small style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
              opacity: .6;
              color: #fff;
              transition: all .2s;"></i> intraday account</small>
          </div>
        </div>
        <div class="row">
          <div class="col">
            <h4 style="font-size: 18px;
            color: #fff;
            font-weight: 600;
            opacity: .8;
            text-transform: capitalize;">brokerage plan</h4>
          </div> </div>
        <div class="row">
          <div class="col">
            <h4 style="font-size: 18px;
            color: #fff;
            font-weight: 600;
            opacity: .8;
            text-transform: capitalize;">closure plan</h4>
          </div>
        </div>
        <div class="row">
          <div class="col">
            <h4 style="font-size: 18px;
            color: #fff;
            font-weight: 600;
            opacity: .8;
            text-transform: capitalize;">payout request</h4>
          </div>
        </div>
        <div class="row">
          <div class="col">
            <h4 style="font-size: 18px;
            color: #fff;
            font-weight: 600;
            opacity: .8;
            text-transform: capitalize;">funds transfer</h4>
          </div>
        </div>
      </div>



     
    </div>
  </div>
</div>


<div class="container-fluid p-5" style="background: #222222;">
  <div class="row">
    <div class="col-md-10">
      <div class="row">
        <div class="col">
          <h4 style="margin-top: 20px; font-size: 18px;
          color: #fff;
          font-weight: 600;
          opacity: .8;
          text-transform: capitalize; padding-left: 50px;">Attention Investors</h4>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <p style="font-size: 12px;
          color: #fff;
          opacity: .7; padding-left: 50px;">1. No need to issue cheques by investors while subscribing to IPO. Just write the bank account number and sign in the application form to authorize your bank to make payment in case of allotment. No worries for refund as the money remain in investor’s account.</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <p  style="font-size: 12px;
          color: #fff;
          opacity: .7; padding-left: 50px;">2. Prevent Unauthorized transactions and dabba trading practices in your account</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <p style="font-size: 12px;
          color: #fff;
          opacity: .7; padding-left: 50px;">3. KYC is one time exercise while dealing in securities markets - once KYC is done through a SEBI registered intermediary (broker, DP, Mutual Fund etc.), you need not undergo the same process again when you approach another intermediary</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <p style="font-size: 12px;
          color: #fff;
          opacity: .7; padding-left: 50px;">4. AS PER SEBI DIRECTIVE (CIRCULAR NUMBERS: SEBI/HO/MIRSD/DOP/CIR/P/2020/28 & SEBI/HO/MIRSD/DOP/CIR/P/2020/143), EFFECTIVE FROM 1ST AUGUST 2020, FOR CREATION OF PLEDGE/UNPLEDGE, CLIENTS HAVE TO NECESSARILY AUTHENTICATE THE OTP RECEIVED ON THEIR MOBILE PHONES AND LINK RECEIVED ON THEIR EMAIL IDS. HENCE, ALL CLIENTS ARE REQUESTED TO KINDLY ENSURE THAT THE MOBILE NUMBER AND EMAIL ID REGISTERED WITH US ARE ACTIVE AND WORKING.</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <p style="font-size: 12px;
          color: #fff;
          opacity: .7; padding-left: 50px;">5. We do not give assured returns and neither do our APs promise assured returns to our clients</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <p style="font-size: 12px;
          color: #fff;
          opacity: .7; padding-left: 50px;">6. Please update your E-Mail and Mobile number with us</p>
        </div>
      </div>
    </div>
  </div>
</div>



<div class="container-fluid p-5" style="background: #222222;">
<div class="row">
  <div class="col-md-12">

    <div class="row">
      <div class="col">
        <h4 style="margin-top: 20px;font-size: 18px;
        color: #fff;
        font-weight: 600;
        opacity: .8;
        text-transform: capitalize; padding-left: 45px;">Risk Disclosure on Derivatives</h4>
      </div>
    </div>
    <div class="row">
      <div class="col">
        <ul style="padding-left: 80px;">
          <li style="font-size: 12px;
          color: #fff;
          opacity: .7;"> 9 out of 10 individual traders in equity Futures and Options Segment, incurred net losses.</li>
          <li style="font-size: 12px;
          color: #fff;
          opacity: .7;"> On an average, loss makers registered net trading loss close to ₹50,000.</li>
          <li style="font-size: 12px;
          color: #fff;
          opacity: .7;"> Over and abovethe net trading losses incurred, loss makers expended anadditional 28%of net trading losses as transaction costs.</li>
          <li style="font-size: 12px;
          color: #fff;
          opacity: .7;">Those making net trading profits,incurredbetween 15% to 50%of such profitsas transaction cost.</li>
        </ul>
      </div>
    </div>
    
  </div>
</div>
</div>

<div class="container-fluid pb-5 " style="background: #222222;">
  <div class="row">
    <div class="col-md-10">
      <div class="row">
        <div class="col">
           <p style="    font-size: 12px;
           color: #fff;
           opacity: .7; padding-left: 80px;">Source:</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <a href="" style="color: #428bca;text-decoration: none;
    background-color: transparent; font-size: 12px; opacity: .7; padding-left: 80px;">1. SEBI study dated January 25, 2023 on “Analysis of Profit and Loss of Individual Traders dealing in equity Futures and Options (F&O) Segment”, wherein Aggregate Level findings 
    </a>
    <a href="" style="color: #428bca;text-decoration: none;
    background-color: transparent; font-size: 12px; opacity: .7; padding-left: 80px;">are based on annual Profit/Loss incurred by individual traders in equity F&O during FY 2021-22.</a>
        </div>
      </div>
    </div>
  </div>
</div>


<div class="container-fluid" style="    background-color: #1b1b1b;">
<div class="row">
  <div class="col-md-12">
    <div class="row">
      <div class="col">
        <h4 style="margin-top: 20px;font-size: 18px;
        color: #fff;
        font-weight: 600;
        opacity: .8;
        text-transform: capitalize; padding-left: 80px;"> Useful links</h4>
      </div>
    </div>
    <div class="row">
      <div class="col" style="padding-left: 80px;">
        <a href="" style="font-size: 14px;
        opacity: .6;
        color: #fff;
        transition: all .2s;text-decoration: none;
        background-color: transparent;  border-right: solid 1px #585858 !important; float: left !important;
        padding: 2px 29px 2px 25px !important; ">NSE</a>
        <a href="" style="font-size: 14px;
        opacity: .6;
        color: #fff;
        transition: all .2s;text-decoration: none;
        background-color: transparent;  border-right: solid 1px #585858 !important; float: left !important;
        padding: 2px 29px 2px 25px !important; ">BSE</a>
        <a href="" style="font-size: 14px;
        opacity: .6;
        color: #fff;
        transition: all .2s;text-decoration: none;
        background-color: transparent;  border-right: solid 1px #585858 !important; float: left !important;
        padding: 2px 29px 2px 25px !important; ">NSDL</a>
        <a href="" style="font-size: 14px;
        opacity: .6;
        color: #fff;
        transition: all .2s;text-decoration: none;
        background-color: transparent;  border-right: solid 1px #585858 !important; float: left !important;
        padding: 2px 29px 2px 25px !important; ">CDSL </a>
        <a href="" style="font-size: 14px;
        opacity: .6;
        color: #fff;
        transition: all .2s;text-decoration: none;
        background-color: transparent;  border-right: solid 1px #585858 !important; float: left !important;
        padding: 2px 29px 2px 25px !important; ">SEBI</a>
        <a href="" style="font-size: 14px;
        opacity: .6;
        color: #fff;
        transition: all .2s;text-decoration: none;
        background-color: transparent;  border-right: solid 1px #585858 !important; float: left !important;
        padding: 2px 29px 2px 25px !important; ">AMFI</a>
        <a href="" style="font-size: 14px;
        opacity: .6;
        color: #fff;
        transition: all .2s;text-decoration: none;
        background-color: transparent;  border-right: solid 1px #585858 !important; float: left !important;
        padding: 2px 29px 2px 25px !important; ">smart ODR</a>
      </div>
     
    </div>
    <div class="row pt-3">
      <div class="col" style="padding-left: 90px;">
        <a href="" style="color: #9e9e9e;
    opacity: .8; text-decoration: none;
    background-color: transparent;">Privacy Policy</a>
        <a href="" style="color: #9e9e9e;
        opacity: .8; text-decoration: none;
        background-color: transparent;">Disclaimer</a>
        <a href="" style="color: #9e9e9e;
        opacity: .8; text-decoration: none;
        background-color: transparent;">Compliance</a>
        <a href="" style="color: #9e9e9e;
        opacity: .8; text-decoration: none;
        background-color: transparent;">Terms $ Conditions</a>
        <a href="" style="color: #9e9e9e;
        opacity: .8; text-decoration: none;
        background-color: transparent;">Sitemap</a>
      </div>
      <div class="col">
        <p style="font-size: 14px;
        opacity: .5;
        color: #fff;">
          Copyright © 2020 Mangal Keshav Financial Services LLP. All rights reserved.
       </p>
      </div>
    </div>
  </div>
</div>


</div>
</body>
</html>
