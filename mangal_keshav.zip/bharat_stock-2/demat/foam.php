<?php
require '../classes/Database.php';

$error = "";
$email = "";

// Check if email is provided in the URL
if (isset($_GET['email'])) {
    $email = $_GET['email'];

    // Create a new Database connection
    $database = new Database();
    $conn = $database->connDb();

    // SQL Query to get data from `demat` table
    $dematQuery = "SELECT `id`, `name`, `email`, `password`, `phone`, `gender`, `pan`, `dob`, `adhar_no`, `status`, `otp`, `reset_token`, `email_verified`, `verification_token`, `otp_expiry`, `code`, `file` FROM `demat` WHERE `email` = ?";
    $dematStmt = $conn->prepare($dematQuery);
    $dematStmt->bind_param("s", $email);
    $dematStmt->execute();
    $dematResult = $dematStmt->get_result();

    // SQL Query to get data from `doc` table
    $docQuery = "SELECT `id`, `email`, `file`, `sign` FROM `doc` WHERE `email` = ?";
    $docStmt = $conn->prepare($docQuery);
    $docStmt->bind_param("s", $email);
    $docStmt->execute();
    $docResult = $docStmt->get_result();

    // Fetch demat data
    if ($dematResult->num_rows > 0) {
        $dematData = $dematResult->fetch_assoc();
    } else {
        $error = "No data found in the `demat` table for this email.";
    }

    // Fetch doc data
    if ($docResult->num_rows > 0) {
        $docData = $docResult->fetch_assoc();
    } else {
        $error = "No data found in the `doc` table for this email.";
    }

    $conn->close();
} else {
    $error = "Email parameter is missing.";
}
if($dematData['status'] == 1){
    $msg="wait admin approval";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Data for <?php echo htmlspecialchars($email); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/js/all.min.js">
  
</head>
<body>



<img src="../image/MAngal-KEshav-logo.png" class="rounded mx-auto d-block" alt="...">


    
<div class="container box-shadow " style="background:#fff;  border-radius:50px;   ">
                  <h1 class="text-center " style="margin-top:30px; text-shadow: 1px 1px 1px black, 5px 5px 7px black;">Demat Information</h1>
         

                    <div class="row justify-content-center " >
                        <div class="col-md-5 p-4" style="border-radius:30px; border:1px solid black; margin-top:50px; margin-bottom:60px; box-shadow: rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px; ">
                        <?php if (!empty($error)) { ?>
        <p class="error"><?php echo $error; ?></p>
    <?php } else { ?>
        
                        <form action="" method="POST">
                        <div class="col">
                        <label>ID:</label>
            <input type="text" value="<?php echo $dematData['id']; ?>" readonly style="width:390px; margin-bottom:10px;">
  <div class="mb-3">
  <label>Name:</label>
            <input type="text" value="<?php echo $dematData['name']; ?>" readonly style="width:363px;">

  </div>
  <div class="mb-3">
  <label>Email:</label>
            <input type="email" value="<?php echo $dematData['email']; ?>" readonly style="width:366px;">
  </div>
  <div class="mb-3">
  <label>Phone:</label>
  <input type="text" value="<?php echo $dematData['phone']; ?>" readonly style="width:360px;">
  </div>
  <div class="mb-3">
  <label>Gender:</label>
  <input type="text" value="<?php echo $dematData['gender']; ?>" readonly style="width:351px;">
  </div>
  <div class="mb-3">
  <label>PAN:</label>
  <input type="text" value="<?php echo $dematData['pan']; ?>" readonly style="width:376px; margin-bottom:5px;">
  <div class="mb-3">
  <label>DOB:</label>
  <input type="date" value="<?php echo $dematData['dob']; ?>" readonly style="width:373px;">
  </div>
  <div class="mb-3">
  <label>Aadhar No:</label>
  <input type="text" value="<?php echo $dematData['adhar_no']; ?>" readonly style="width:330px;">
  </div>
  <div class="mb-3">
  <label>Status:</label>
            <input type="text" value="<?php echo $msg; ?>" readonly style="width:365px;">
  </div>
  <div class="mb-3">
  
  <label>Code:</label>
            <input type="text" value="<?php echo $dematData['code']; ?>" readonly style="width:370px;">

  </div>
  <div class="mb-3">
  
  <label>Uploaded File:</label>
            <a href="../upload/<?php echo $dematData['file']; ?>" target="_blank" style="text-decoration:none; color:maroon;">View File</a>

  </div>
  

</form>
                        </div>
                    </div>
                </div>






                
<div class="container"  style="  border-radius:50px;   ">
<h1 class="text-center " style="margin-top:30px; text-shadow: 1px 1px 1px black, 5px 5px 7px black;">Document Information</h1>
    <div class="row justify-content-center">
        <div class="col-md-5 p-4"  style="border-radius:30px; border:1px solid black; margin-top:50px; margin-bottom:60px; box-shadow: rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px; ">
            <div class="row">
                <div class="col">
                <form action="" method="POST">
                       
                       <div class="mb-3">
                       <label>Uploaded Document:</label>
                       <a href="../uploads_doc/<?php echo $docData['file']; ?>" target="_blank" style="text-decoration:none; color:maroon;">View Document</a>
                       </div>
                       <div class="mb-3">
                       
                       <label>Digital Signature:</label>
                                 <a href="../uploads_doc/<?php echo $docData['sign']; ?>" target="_blank" style="text-decoration:none; color:maroon;">View Signature</a>
                                 </div>
                       </div>
                       
                       </div>
                       
                     
                       
                     </form>
                     <a href="login.php" style="text-decoration: none;"><button class="btn btn-dark">Submit</button></a>
                         <?php } ?>
                </div>
            </div>
        </div>
    </div>
</div>


</body>
</html>

