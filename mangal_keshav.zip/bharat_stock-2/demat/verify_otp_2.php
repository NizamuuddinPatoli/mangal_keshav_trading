<?php
require '../classes/Database.php';
require '../classes/Demat.php';

$error = "";
$msg = "";

// Check if email and OTP are provided
if (isset($_GET['email']) && !empty($_GET['email'])) {
    $email = $_GET['email'];

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $entered_otp = $_POST['otp'];

        // Establish a database connection
        $database = new Database();
        $conn = $database->connDb();

        // Retrieve the OTP and expiry time from the database for this email
        $stmt = $conn->prepare("SELECT otp, otp_expiry FROM demat WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($stored_otp, $otp_expiry);
            $stmt->fetch();

            // Check if the entered OTP matches the stored OTP and is within the expiry time
            if ($stored_otp == $entered_otp) {
                if (new DateTime() < new DateTime($otp_expiry)) {
                    $msg = "OTP verified successfully. Your email is now verified.";
                    
                    // Clear OTP after successful verification
                    $stmt = $conn->prepare("UPDATE demat SET otp = NULL, otp_expiry = NULL WHERE email = ?");
                    $stmt->bind_param("s", $email);
                    $stmt->execute();

                    // Redirect to success.php after OTP verification
                    header('Location: success.php?email=' . urlencode($email));
                    exit;

                } else {
                    $error = "The OTP has expired. Please request a new one.";
                }
            } else {
                $error = "The OTP you entered is incorrect.";
            }
        } else {
            $error = "No OTP found for this email.";
        }

        $stmt->close();
        $conn->close();
    }
} else {
    $error = "No email provided.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify OTP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/js/all.min.js">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
            text-align: center;
        }

        h2 {
            color: maroon;
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 10px;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            background-color: #f9f9f9;
            font-size: 16px;
        }

        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #45a049;
        }

        p {
            color: red;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Verify OTP</h2>
        <div>
            <?php if ($msg): ?>
                <p style="color: green;"><?php echo htmlspecialchars($msg); ?></p>
            <?php elseif ($error): ?>
                <p><?php echo htmlspecialchars($error); ?></p>
            <?php endif; ?>
        </div>

        <form method="POST">
            <input type="hidden" name="email" value="<?php echo htmlspecialchars($email); ?>">
            <label for="otp">Enter OTP:</label>
            <input type="text" id="otp" name="otp" required>
            <button type="submit" class="btn btn-dark">Verify OTP</button>
        </form>
    </div>
</body>
</html>

