<?php
require '../classes/Database.php';
require '../classes/Demat.php';

$error = "";
$msg = "";

// Check if email is provided
if (isset($_GET['email']) && !empty($_GET['email'])) {
    $email = $_GET['email'];

    // Establish a database connection
    $database = new Database();
    $conn = $database->connDb();

    // Update the email_verified status in the database
    $stmt = $conn->prepare("UPDATE demat SET status = 1 WHERE email = ?");
    $stmt->bind_param("s", $email);

    if ($stmt->execute()) {
        $msg = "Email verified successfully. You can now log in.";

        // Redirect to login.php after updating the status
        header("Location: termcon.php?email=" . urlencode($email));
        exit;
    } else {
        $error = "There was an error verifying your email. Please try again.";
    }

    $stmt->close();
    $conn->close();
} else {
    $error = "No email provided.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Success</title>
</head>
<body>
    <div>
        <?php if ($msg): ?>
            <p><?php echo $msg; ?></p>
        <?php elseif ($error): ?>
            <p><?php echo $error; ?></p>
        <?php endif; ?>
    </div>
</body>
</html>
