<?php
require '../classes/Database.php';
require '../classes/Demat.php';
require '../smtp/PHPMailerAutoload.php';

$error = "";
$msg = "";

if (isset($_GET['email']) && isset($_GET['code'])) {
    $email = $_GET['email'];
    $code = $_GET['code'];
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
        $database = new Database();
        $conn = $database->connDb();

        // Verify if user exists
        $userData = Demat::authentication($conn, $email);

        if ($userData && $userData['email'] == $email) {
            // Handle file upload
            $targetDir = "../verify_image/";
            $fileName = basename($_FILES["file"]["name"]);
            $targetFilePath = $targetDir . $fileName;
            $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

            // Allow only certain file formats
            $allowedTypes = array('jpg', 'png', 'jpeg', 'gif');
            if (in_array($fileType, $allowedTypes)) {
                // Upload file to the server
                if (move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath)) {
                    // Generate OTP and code
                    $otp = rand(100000, 999999); // 6-digit OTP
                    
                    // Prepare SQL statement to update the demat table
                    $stmt = $conn->prepare("UPDATE `demat` SET `code` = ?, `file` = ?, `otp` = ?, `otp_expiry` = DATE_ADD(NOW(), INTERVAL 15 MINUTE) WHERE `email` = ?");
                    
                    if ($stmt === false) {
                        die('Prepare failed: ' . $conn->error);
                    }

                    // Bind parameters
                    $stmt->bind_param("ssss", $code, $fileName, $otp, $email);

                    // Execute the statement
                    if ($stmt->execute()) {
                        // Send OTP via email
                        $mail = new PHPMailer(true);
                        $mail->isSMTP();
                        $mail->Host = "smtp.gmail.com";
                        $mail->Port = 587;
                        $mail->SMTPSecure = 'tls';
                        $mail->Username = "fyp.ms2024@gmail.com";
                        $mail->Password = "mrao ddzx ivls judu";
                        $mail->setFrom("fyp.ms2024@gmail.com");
                        $mail->addAddress($email);
                        $mail->SMTPAuth = true;
                        $mail->isHTML(true);
                        $mail->CharSet = 'UTF-8';
                        $mail->Body = 'Your OTP for password reset is: ' . $otp;
                        $mail->Subject = 'Password Reset OTP - FYP management system';
                        $mail->SMTPOptions = array('ssl' => array(
                            'verify_peer' => false,
                            'verify_peer_name' => false,
                            'verify_peer_signed' => false,
                        ));

                        // Send the email
                        if ($mail->send()) {
                            echo 'OTP sent to your email. Check your inbox.';
                            // Redirect to page for OTP verification
                            header('Location: verify_otp_2.php?email=' . urlencode($email) );
                            exit;
                        } else {
                            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
                        }
                    } else {
                        echo "Database update failed: " . $stmt->error;
                    }
                } else {
                    echo 'File upload failed.';
                }
            } else {
                echo 'Invalid file format. Only JPG, JPEG, PNG, and GIF files are allowed.';
            }
        } else {
            echo 'Email address not found in the database.';
        }
    } else {
       // echo 'Invalid file or request method.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Verification</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/js/all.min.js">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            background-color: white;
            padding: 20px 40px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }

        h2 {
            text-align: center;
            color: maroon;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }

        input[type="text"], input[type="file"], input[type="number"] {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        input[readonly] {
            background-color: #e9ecef;
        }

        button {
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #45a049;
        }

        .captcha-container {
            display: flex;
            align-items: center;
        }

        .captcha-container input {
            width: 50px;
            text-align: center;
            margin: 0 5px;
        }

        .note {
            font-size: 14px;
            color: #777;
            margin-bottom: 15px;
        }

        p {
            text-align: center;
        }

        .message {
            text-align: center;
            margin-bottom: 15px;
            color: #d9534f; /* Default error color */
        }

        .message.success {
            color: #5cb85c;
        }
    </style>
    <script>
        function generateCaptcha() {
            var num1 = Math.floor(Math.random() * 10);
            var num2 = Math.floor(Math.random() * 10);
            document.getElementById("num1").value = num1;
            document.getElementById("num2").value = num2;
            document.getElementById("captchaResult").value = num1 + num2;
        }

        function validateCaptcha() {
            var userAnswer = document.getElementById("captchaInput").value;
            var correctAnswer = document.getElementById("captchaResult").value;
            if (parseInt(userAnswer) === parseInt(correctAnswer)) {
                return true;
            } else {
                alert("Incorrect captcha. Please try again.");
                return false;
            }
        }

        window.onload = generateCaptcha;
    </script>
</head>
<body>
    <div class="container">
        <h2>Email Verification</h2>

        <!-- Display any server-side messages -->
        <div class="message">
            <?php if ($msg): ?>
                <p class="success"><?php echo htmlspecialchars($msg); ?></p>
            <?php elseif ($error): ?>
                <p><?php echo htmlspecialchars($error); ?></p>
            <?php endif; ?>
        </div>

        <form method="POST" enctype="multipart/form-data" onsubmit="return validateCaptcha()">
            <label>Email</label>
            <input type="text" name="email" value="<?php echo htmlspecialchars($email); ?>" readonly>

            <label>Solve this:</label>
            <div class="captcha-container">
                <input type="text" id="num1" disabled> + 
                <input type="text" id="num2" disabled> = 
                <input type="number" id="captchaInput" required>
            </div>

            <input type="hidden" id="captchaResult">

            <label>Generated Code</label>
            <input type="text" name="code" value="<?php echo $code; ?>" readonly>
            <p class="note">Please write the generated code on paper and upload the image like this.</p>
            
            <img src="../image/th.jpg" alt="sample">

            <label for="file">Upload Image</label>
            <input type="file" name="file" id="file" required>

            <button type="submit" class="btn btn-dark">Verify Email</button>
        </form>
    </div>
</body>
</html>

