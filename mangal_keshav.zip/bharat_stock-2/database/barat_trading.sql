-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 19, 2024 at 02:23 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `barat_trading`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(150) NOT NULL,
  `otp` text DEFAULT NULL,
  `reset_token` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`, `otp`, `reset_token`) VALUES
(1, 'admin', 'admin@gmail.com', '$2y$10$PrZVLEj1KW4HGsp.IGVQvuVoWc47nPn7FIBzemB4HsCK.y2A6LPCe', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `demat`
--

CREATE TABLE `demat` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(150) NOT NULL,
  `phone` varchar(150) NOT NULL,
  `gender` varchar(150) NOT NULL,
  `pan` varchar(150) NOT NULL,
  `dob` varchar(150) NOT NULL,
  `adhar_no` varchar(150) NOT NULL,
  `status` varchar(150) NOT NULL,
  `otp` varchar(150) NOT NULL,
  `reset_token` varchar(150) NOT NULL,
  `email_verified` tinyint(1) DEFAULT 0,
  `verification_token` varchar(255) DEFAULT NULL,
  `otp_expiry` varchar(120) DEFAULT NULL,
  `code` varchar(150) DEFAULT NULL,
  `file` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `demat`
--

INSERT INTO `demat` (`id`, `name`, `email`, `password`, `phone`, `gender`, `pan`, `dob`, `adhar_no`, `status`, `otp`, `reset_token`, `email_verified`, `verification_token`, `otp_expiry`, `code`, `file`) VALUES
(1, 'ali', 'ali@gmail.com', '$2y$10$s6e/JX3Q4Z8EBpJ4HjzBHuU0W2OVkAUCxZFBlzYN6ugYK/qDHBTSS', '1235676', 'male', '12435', '2024-09-26', '12343546', 'active', '', '', 0, NULL, NULL, NULL, NULL),
(4, 'asma', 'asma@gmail.com', '$2y$10$ob16BZSB71ArF/HHAJuHpe0NRMlMbPO3gOhImme49BCEIvxBVj70O', '123456', 'Male', '12343556', '2024-09-10', '12243535', 'inactive', '', '', 0, NULL, NULL, NULL, NULL),
(5, 'zain', 'zain@gmail.com', '$2y$10$xoNYQsDZw.lEUMmSGkC3pONLZnnBA62DqrNwU3r/..r/MHlSeRGie', '2416573586', 'Male', '356283684', '2024-09-01', '53725676', 'active', '', '', 0, NULL, NULL, NULL, NULL),
(7, 'sima', 'sima@gmail.com', '$2y$10$f8X3SzdgdKK4MneLAX9X5OfL0cb2PLkuaplvcks9YzIkojQw6TK7a', '231426', 'Male', '436517', '2024-09-11', '413575', 'inactive', '791255', '', 0, NULL, '2024-09-17 21:50:53', NULL, NULL),
(12, 'ban', 'ban@gmail.com', '$2y$10$qxok1A9y2V5B6we6V/M5fu1aPfdLBAuRaEgUwFQD/.njbIsfzMzXm', '52376847', 'Male', '51351726', '2024-09-01', '64628378', '1', '', '', 0, NULL, NULL, NULL, NULL),
(14, 'nizaaa', 'niz@gmail.com', '$2y$10$4WwJrltWUkoapm.AEdypkOsvUueV/nFelFEEBjPQ6/MH.a2oPao4m', '4767322', 'Male', '5361576', '2024-09-10', '6372168', '1', '', '', 0, NULL, NULL, NULL, NULL),
(16, 'aliz', 'aliz@gmaiil.com', '$2y$10$g7KctKP/DALq5SWBOLtzAeE/JgShg6ORUlcsk9pyg2wHvK6T4aEri', '12341563', 'Male', '2354653', '2024-09-01', '4265137', 'inactive', '672022', '', 0, NULL, '2024-09-18 14:34:09', '504414', 'blooddrive2.jpg'),
(17, 'sara', 'sara@gmail.com', '$2y$10$6M/SehHVVMG450xTQnAJgeWC3nq/DwWsV232ut3fT/cqihFNscomK', '124165723', 'Male', '53267618', '2024-09-01', '3527617', '1', '', '', 0, NULL, NULL, '954587', 'blooddrive2.jpg'),
(19, 'kashish', 'kashish@gmail.com', '$2y$10$Cd3TkaKG7.i2nojXU1db3OtthJEhWREwiWSEfDTTFhjvUXo3Bqtdi', '12241534613', 'Male', '421642643', '2024-09-01', '3416576', '1', '', '', 0, NULL, NULL, '164637', '360_F_143238306_lh0ap42wgot36y44WybfQpvsJB5A1CHc.jpg'),
(23, 'micky', 'micky@gmail.com', '$2y$10$jP8EYMlKirPSRcrUh4SvLeCGcB5AzB3oZJktDImu5mr6nUk1zd2U.', '12345678', 'Male', '1234567', '2024-09-01', '123456', '1', '', '', 0, NULL, NULL, '503703', '360_F_317254576_lKDALRrvGoBr7gQSa1k4kJBx7O2D15dc.jpg'),
(24, 'kashish', 'kashishlohana09@gmail.com', '$2y$10$7U5Dsm/EsmB/eulWqLDrwu9er6PPbyGSarAKLf4R4CuPR9Vn8JhU6', '123456667', 'male', '134567123456', '2024-09-08', '1234566', '0', '', '', 0, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `doc`
--

CREATE TABLE `doc` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `file` varchar(250) NOT NULL,
  `sign` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doc`
--

INSERT INTO `doc` (`id`, `email`, `file`, `sign`) VALUES
(5, 'micky@gmail.com', '360_F_317254576_lKDALRrvGoBr7gQSa1k4kJBx7O2D15dc.jpg', '360_F_317254576_lKDALRrvGoBr7gQSa1k4kJBx7O2D15dc.jpg'),
(6, 'kashishlohana09@gmail.com', '360_F_317254576_lKDALRrvGoBr7gQSa1k4kJBx7O2D15dc.jpg', 'blooddrive.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `d_payment`
--

CREATE TABLE `d_payment` (
  `id` int(11) NOT NULL,
  `demat_id` int(11) NOT NULL,
  `dop` varchar(150) NOT NULL,
  `bank` varchar(250) NOT NULL,
  `file` varchar(250) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `d_payment`
--

INSERT INTO `d_payment` (`id`, `demat_id`, `dop`, `bank`, `file`, `status`) VALUES
(1, 21, '2024-09-09', 'Axis Bank', 'blooddrive.jpg', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `dop` varchar(150) NOT NULL,
  `bank` varchar(250) NOT NULL,
  `file` varchar(250) NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `user_id`, `dop`, `bank`, `file`, `status`) VALUES
(1, 1, '2024-08-11', 'Airtel Payments Bank', '360_F_143238306_lh0ap42wgot36y44WybfQpvsJB5A1CHc.jpg', 'approved'),
(3, 1, '2024-08-14', 'India Post Payments Bank', 'blooddrive2.jpg', 'pending'),
(4, 1, '2024-08-27', 'India Post Payments Bank', 'blooddrive2.jpg', 'rejected'),
(5, 5, '2024-08-14', 'India Post Payments Bank', '360_F_317254576_lKDALRrvGoBr7gQSa1k4kJBx7O2D15dc.jpg', 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `dob` varchar(150) NOT NULL,
  `phone` varchar(150) NOT NULL,
  `status` int(11) NOT NULL,
  `otp` text DEFAULT NULL,
  `reset_token` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `dob`, `phone`, `status`, `otp`, `reset_token`) VALUES
(1, 'ali', 'ali@gmail.com', '$2y$10$UGbuB5FuD6bD4YtGC123dOa41rutqge11pWa84cCkXz9z/6x0m71S', '2024-08-21', '123447', 1, '687194', NULL),
(3, 'Ahmed', 'ahmed@gmail.com', '$2y$10$QT9OqUhBcA1wVCFHn5XIRu.0Le9HKl02ykow4DBhyZP/bObcAspcu', '2024-08-05', '6827479', 1, NULL, NULL),
(4, 'asma', 'asma@gmail.com', '$2y$10$nl/Ze8CDSvcUGJ2bk7aqx.Bc/Ix4Kg51h4iyZ0kQIM0JbnFZUsOgC', '2024-08-04', '537255566666', 1, NULL, NULL),
(5, 'zain', 'zain@gmail.com', '$2y$10$.hkjlRz.mmOCFYjYzAvJQuaxZbkB7xv8hpSinAE2hZfBu5tN0YuGq', '2024-01-01', '6482724979', 1, '865700', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `demat`
--
ALTER TABLE `demat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doc`
--
ALTER TABLE `doc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `d_payment`
--
ALTER TABLE `d_payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `demat`
--
ALTER TABLE `demat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `doc`
--
ALTER TABLE `doc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `d_payment`
--
ALTER TABLE `d_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
