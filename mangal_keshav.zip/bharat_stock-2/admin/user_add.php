<?php
session_start();
require '../classes/Database.php';
require '../classes/User.php';

if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'admin') {
    header('Location: ../logout.php');
    exit();
}

$database = new Database();
$conn = $database->connDb();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $dob = $_POST['dob'];
    $phone = $_POST['phone'];
    $status = $_POST['status'];

    $insertQuery = "INSERT INTO `users` (`name`, `email`, `password`, `dob`, `phone`, `status`) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($insertQuery);
    $stmt->bind_param("ssssss", $name, $email, $password, $dob, $phone, $status);
    $stmt->execute();

    header("Location: user_manage.php"); // Redirect to the manage page
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/js/all.min.js">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    
   
</head>
<body style="background:#fff;">
    
     
<?php require "nav-bar.php"; ?>



<div class="container-fluid mt-5" >
             <h1 class="text-center mb-5" style="margin-top:100px ;   text-shadow: 1px 1px 1px black, 3px 3px 5px black;">Add New User</h1>
                <div class="row justify-content-center">
                    <div class="col-md-4" style="border:1px solid black; border-radius:15px; padding:10px; box-shadow: rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px;">
                           
                <form method="post" action="">

                <div class="form-group mb-3">
                <label for="name">Name
                  
                </label>
    <input type="text" class="form-control" placeholder=" Name" aria-label="First name"  type="text" name="name" required style="border-radius:15px; width:350px;">
  </div>
  <div class="mb-3">
  <label for="email">Email</label>
    
    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Email" type="email" name="email" required style="border-radius:45px; width:350px;">
    
  </div>
  <div class="mb-3">
  <label for="password">Password</label>
    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" type="password" name="password" required style="border-radius:45px; width:350px;">
  </div>
  
  <div class="form-group">
            <label for="dob">Date of Birth</label>
            <input type="date" name="dob" required>
  </div>
  <div class="form-group mb-3">
  <label for="phone">Phone</label>
            <input type="text" name="phone" required placeholder="Phone" style="width:290px; border-radius:40px; border:1px solid gray; padding:5px;">
  </div>
  
  
  <div class="form-group">
            <label for="status">Status</label>
            <select name="status" id="status">
                <option value="1">Active</option>
                <option value="0">Inactive</option>
            </select>
              </div>
              <div class="form-group">

<button type="submit"  class="btn btn-dark" style=" box-shadow:2px 2px 5px 5px black;">Add User</button>
  </div>
 
</form>

                    </div>
                </div>
             </div>


             <?php require "footer.php"; ?>
    
    
</body>
</html>
