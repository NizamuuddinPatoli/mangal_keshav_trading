<?php
session_start();
require '../classes/Database.php';
require '../classes/Demat.php';
require '../classes/User.php';

if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'admin') {
    header('Location: ../logout.php');
    exit();
}

$database = new Database();
$conn = $database->connDb();

$user_id = $_GET['id'];
$user = Demat::getById($conn, $user_id); // Fetch user data based on the ID

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $dob = $_POST['dob'];
    $phone = $_POST['phone'];
    $status = $_POST['status'];
    $pan = $_POST['pan'];
    $adhar_no = $_POST['adhar_no'];
    $gender = $_POST['gender'];
    $code = $_POST['code'];
    $file = $_POST['file'];

    // Update query for `demat` table
    $updateQuery = "UPDATE `demat` SET `name` = ?, `email` = ?, `dob` = ?, `phone` = ?, `status` = ?, `pan` = ?, `adhar_no` = ?, `gender` = ?, `code` = ?, `file` = ? WHERE `id` = ?";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("ssssssssssi", $name, $email, $dob, $phone, $status, $pan, $adhar_no, $gender, $code, $file, $user_id);
    $stmt->execute();

    header("Location: Demat_manage.php"); // Redirect after updating
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body style="background:#fff;">
   
<?php require "nav-bar.php"; ?>

<div class="container-fluid mt-5">
    <h1 class="text-center mb-5" style="margin-top:100px; text-shadow: 1px 1px 1px black, 3px 3px 5px black;">Edit User</h1>
    <div class="row justify-content-center">
        <div class="col-md-6" style="border:1px solid black; border-radius:15px; padding:10px;">
            <form method="post" action="">

                <div class="col mb-3">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required style="border-radius:15px;">
                </div>

                <div class="mb-3">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required style="border-radius:45px;">
                </div>

                <div class="form-group">
                    <label>Date of Birth</label>
                    <input type="date" class="form-control" name="dob" value="<?php echo htmlspecialchars($user['dob']); ?>" required>
                </div>

                <div class="form-group mt-3">
                    <label>Phone</label>
                    <input type="text" class="form-control" name="phone" value="<?php echo htmlspecialchars($user['phone']); ?>" required style="border-radius:15px;">
                </div>

                <div class="form-group mt-3">
                    <label>PAN</label>
                    <input type="text" class="form-control" name="pan" value="<?php echo htmlspecialchars($user['pan']); ?>" required style="border-radius:15px;">
                </div>

                <div class="form-group mt-3">
                    <label>Adhar No</label>
                    <input type="text" class="form-control" name="adhar_no" value="<?php echo htmlspecialchars($user['adhar_no']); ?>" required style="border-radius:15px;">
                </div>

                <div class="form-group mt-3">
                    <label>Gender</label>
                    <select name="gender" class="form-control" style="border-radius:15px;">
                        <option value="male" <?php if($user['gender'] == 'male') echo 'selected'; ?>>Male</option>
                        <option value="female" <?php if($user['gender'] == 'female') echo 'selected'; ?>>Female</option>
                    </select>
                </div>

                
                <div class="form-group mt-3">
                    <label>Status</label>
                    <select name="status" class="form-control" style="border-radius:15px;">
                        <option value="active" <?php if($user['status'] == 'active') echo 'selected'; ?>>Active</option>
                        <option value="inactive" <?php if($user['status'] == '0') echo 'selected'; ?>>Inactive</option>
                    </select>
                </div>

                <div class="form-group mt-3">
                    <button type="submit" class="btn btn-dark" style="border-radius:12px;">Save Changes</button>
                </div>
                
            </form>
        </div>
    </div>
</div>

<?php require "footer.php"; ?>
</body>
</html>
