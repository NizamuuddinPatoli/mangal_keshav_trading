<?php
session_start();
require '../classes/Database.php';
require '../classes/Demat.php';
require '../classes/User.php';

if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'admin') {
    header('Location: ../logout.php');
    exit();
}

$database = new Database();
$conn = $database->connDb();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $dob = $_POST['dob'];
    $phone = $_POST['phone'];
    $status = $_POST['status'];
    $gender = $_POST['gender'];
    $pan = $_POST['pan'];
    $adhar_no = $_POST['adhar_no'];

    // Initialize file paths
    $targetDir = "../uploads_doc/";
    $filePath = null;
    $signPath = null;

    // Handle file upload (Document)
    if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
        $fileName = basename($_FILES['file']['name']);
        $targetFilePath = $targetDir . $fileName;
        $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);
        $allowedTypes = array('jpg', 'png', 'pdf', 'jpeg');

        if (in_array($fileType, $allowedTypes)) {
            if (move_uploaded_file($_FILES['file']['tmp_name'], $targetFilePath)) {
                $filePath = $targetFilePath;
            } else {
                echo "Error uploading file.";
                exit();
            }
        } else {
            echo "Only JPG, PNG, JPEG, and PDF files are allowed.";
            exit();
        }
    }

    // Handle signature upload
    if (isset($_FILES['sign']) && $_FILES['sign']['error'] == 0) {
        $signFileName = basename($_FILES['sign']['name']);
        $signFilePath = $targetDir . $signFileName;
        $signFileType = pathinfo($signFilePath, PATHINFO_EXTENSION);

        if (in_array($signFileType, $allowedTypes)) {
            if (move_uploaded_file($_FILES['sign']['tmp_name'], $signFilePath)) {
                $signPath = $signFilePath;
            } else {
                echo "Error uploading signature.";
                exit();
            }
        } else {
            echo "Only JPG, PNG, JPEG, and PDF files are allowed for signature.";
            exit();
        }
    }

    // Insert data into `demat` table
    $insertQuery = "INSERT INTO `demat` (`name`, `email`, `password`, `dob`, `phone`, `status`, `gender`, `pan`, `adhar_no`, `file`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($insertQuery);
    $stmt->bind_param("ssssssssss", $name, $email, $password, $dob, $phone, $status, $gender, $pan, $adhar_no, $filePath);
    
    if ($stmt->execute()) {
        // Insert document and signature paths into the `doc` table
        $docQuery = "INSERT INTO `doc` (`email`, `file`, `sign`) VALUES (?, ?, ?)";
        $docStmt = $conn->prepare($docQuery);
        $docStmt->bind_param("sss", $email, $filePath, $signPath);
        
        if ($docStmt->execute()) {
            // Redirect after successful insertion
            header("Location: demat_manage.php");
            exit();
        } else {
            echo "Error inserting into `doc` table.";
        }
    } else {
        echo "Error inserting into `demat` table.";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous" defer></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body style="background:#fff;">
<?php require "nav-bar.php"; ?>

<div class="container-fluid mt-5">
    <h1 class="text-center mb-5" style="margin-top:100px; text-shadow: 1px 1px 1px black, 3px 3px 5px red;">Add New User</h1>
    <div class="row justify-content-center">
        <div class="col-md-6" style="border:1px solid red; border-radius:15px; padding:10px; box-shadow: rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px;">
            <form method="post" enctype="multipart/form-data">
                <div class="col mb-3">
                    <input type="text" class="form-control" placeholder="Name" name="name" required style="border-radius:15px;">
                </div>
                <div class="mb-3">
                    <input type="email" class="form-control" placeholder="Email" name="email" required style="border-radius:45px;">
                </div>
                <div class="mb-3">
                    <input type="password" class="form-control" placeholder="Password" name="password" required style="border-radius:45px;">
                </div>
                <div class="form-group">
                    <label for="dob">Date of Birth</label>
                    <input type="date" name="dob" required>
                </div>
                <div class="form-group mb-3">
                    <input type="text" name="phone" required placeholder="Phone" style="width:430px; border-radius:40px; border:1px solid gray; padding:5px;">
                </div>
                <div class="form-group">
                    <label for="gender">Gender</label>
                    <select name="gender" id="gender" required>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>
                </div>
                <div class="form-group">
                    <input type="text" name="pan" placeholder="PAN Number" style="width:430px; border-radius:40px; border:1px solid gray; padding:5px;">
                </div>
                <div class="form-group">
                    <input type="text" name="adhar_no" placeholder="Aadhar Number" style="width:430px; border-radius:40px; border:1px solid gray; padding:5px;">
                </div>
                <div class="form-group mb-3">
    <label for="file">Upload File:</label>
    <input type="file" name="file" class="form-control" required style="border-radius:15px;">
  </div>

  <!-- Sign Upload Field -->
  <div class="form-group mb-3">
    <label for="sign">Upload Sign:</label>
    <input type="file" name="sign" class="form-control" required style="border-radius:15px;">
  </div>
                <div class="form-group">
                    <label for="status">Status</label>
                    <select name="status" id="status">
                        <option value="Inactive">Inactive</option>
                        <option value="1">Email Verified</option>
                        <option value="0">Active</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-danger" style="box-shadow:2px 2px 5px 5px red;">Add User</button>
            </form>
        </div>
    </div>
</div>

<?php require "footer.php"; ?>
</body>
</html>
