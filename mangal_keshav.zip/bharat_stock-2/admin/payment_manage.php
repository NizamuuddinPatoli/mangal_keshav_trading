<?php
session_start();
require '../classes/Database.php';
require '../classes/User.php';

if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'admin') {
    header('Location: ../logout.php');
    exit();
}
$database = new Database();
$conn = $database->connDb();

// Fetch payment records
$sql = "SELECT p.id, p.dop, p.bank, p.file, p.status, u.name, u.email 
        FROM payment p 
        JOIN users u ON p.user_id = u.id";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Manage Payments</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/js/all.min.js">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    
   
</head>
<body style="background:#fff;">
    
<?php require "nav-bar.php"; ?>


               
              

<div class="container" style="margin-top:100px;">
<h1 style="  text-shadow: 1px 1px 1px black, 3px 3px 5px black; text-align:center; margin-bottom:30px;">Manage Payments</h1>
    <div class="row justify-content-center">
        <div class="col-md-6 mb-5">
            <div class="row ">
                <div class="col">
                    <table style="box-shadow: rgba(0, 0, 0, 0.56) 0px 22px 70px 4px; text-align:center;border-radius:10px;">
                        <thead style="border:1px solid gray; ">
                        <tr>
      <th scope="col" style="border:1px solid gray;">ID</th>
      <th scope="col" style="border:1px solid gray;">User Name</th>
      <th scope="col" style="border:1px solid gray;">User Email</th>
      <th scope="col" style="border:1px solid gray;">Date of Paymant</th>
      <th scope="col" style="border:1px solid gray;">Bank</th>
      <th scope="col" style="border:1px solid gray;">Screenshot</th>
      <th scope="col" style="border:1px solid gray;">Status</th>
      <th scope="col" style="border:1px solid gray;">Actions</th>
    </tr>
                        </thead>
                        <tbody style="border:1px solid gray; ">
                        <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['dop']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['bank']) . "</td>";
                        echo "<td><a href='../upload/" . htmlspecialchars($row['file']) . "' target='_blank'>View Screenshot</a></td>";
                        echo "<td>" . htmlspecialchars($row['status']) . "</td>";
                        
                        // Actions: Approve or Reject
                        if ($row['status'] === 'pending') {
                            echo "<td>
                                    <a href='payment_action.php?action=approve&id=" . htmlspecialchars($row['id']) . "'>Approve</a> | 
                                    <a href='payment_action.php?action=reject&id=" . htmlspecialchars($row['id']) . "'>Reject</a>
                                  </td>";
                        } else {
                            echo "<td>" . ucfirst($row['status']) . "</td>"; // Display status if already approved/rejected
                        }

                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='8'>No payment records found.</td></tr>";
                }
                ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

                <?php require "footer.php"; ?>
    
</body>
</html>
