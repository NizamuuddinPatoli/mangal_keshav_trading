<?php
session_start();
require '../classes/Database.php';
require '../classes/User.php';

if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'admin') {
    header('Location: ../logout.php');
    exit();
}

$database = new Database();
$conn = $database->connDb();

$user_id = $_SESSION['user_id'];
$activeuser = User::getByAdmin($conn, $user_id);

// Fetch all users
$query = "SELECT `id`, `name`, `email`, `dob`, `phone`, `status` FROM `users`";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    $users = $result->fetch_all(MYSQLI_ASSOC);
} else {
    $users = [];
}

// Handle delete operation
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $deleteQuery = "DELETE FROM `users` WHERE `id` = ?";
    $stmt = $conn->prepare($deleteQuery);
    $stmt->bind_param("i", $delete_id);
    $stmt->execute();
    header("Location: user_manage.php"); // Redirect to refresh the list
    exit();
}

// Handle status update operation
if (isset($_GET['status_id']) && isset($_GET['status'])) {
    $status_id = $_GET['status_id'];
    $new_status = $_GET['status'] == 1 ? 0 : 1;
    $statusQuery = "UPDATE `users` SET `status` = ? WHERE `id` = ?";
    $stmt = $conn->prepare($statusQuery);
    $stmt->bind_param("si", $new_status, $status_id);
    $stmt->execute();
    header("Location: user_manage.php"); // Redirect to refresh the list
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/js/all.min.js">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  
</head>
<body style="background:#fff;">

<?php require "nav-bar.php"; ?>



<div class="container">

    <div class="row justify-content-center">
        <div class="col-md-6 mb-5">
        <div class="header">
            <h1 style="text-align:center;  text-shadow: 1px 1px 1px black, 3px 3px 5px black; margin-top:50px; ">Manage Users</h1>
            <a href="user_add.php" class="add-user btn btn-dark mb-2 ,t-2" style=" padding:10px; ">Add New User</a>
        </div>
            <div class="row" style="border-radius:10px;">
                <div class="col" style="border-radius:10px;">
                    <table style="box-shadow: rgba(0, 0, 0, 0.56) 0px 22px 70px 4px; text-align:center;border-radius:10px;">
                        <thead style="border:1px solid black; border-radius:10px;" >
                        <tr>
      <th scope="col" style="border:1px solid gray; ">ID</th>
      <th scope="col" style="border:1px solid gray;">Name</th>
      <th scope="col" style="border:1px solid gray;">Email</th>
      <th scope="col" style="border:1px solid gray;">Date of Birth</th>
      <th scope="col" style="border:1px solid gray;">Phone Number</th>
      <th scope="col" style="border:1px solid gray;">Status</th>
      <th scope="col" style="border:1px solid gray;">Actions</th>
    </tr>
                        </thead>
                        <tbody style="border:1px solid gray;">
                        <?php foreach ($users as $user): ?>
                    <tr style="border:1px solid black;">
                        <td style="border:1px solid black;"><?php echo htmlspecialchars($user['id']); ?></td>
                        <td style="border:1px solid black;"><?php echo htmlspecialchars($user['name']); ?></td>
                        <td style="border:1px solid black;"><?php echo htmlspecialchars($user['email']); ?></td>
                        <td style="border:1px solid black;"><?php echo htmlspecialchars($user['dob']); ?></td>
                        <td style="border:1px solid black;"><?php echo htmlspecialchars($user['phone']); ?></td>
                        <td style="border:1px solid black;"><?php echo htmlspecialchars($user['status']); ?></td>
                        <td class="actions" >
                            <a href="user_edit.php?id=<?php echo $user['id']; ?>"  style="border:1px solid black; color:black; text-decoration:none;">Edit</a>
                            <a href="user_manage.php?delete_id=<?php echo $user['id']; ?>" onclick="return confirm('Are you sure you want to delete this user?');"  style="border:1px solid black; color:black; text-decoration:none;">Delete</a>
                            <a href="user_manage.php?status_id=<?php echo $user['id']; ?>&status=<?php echo $user['status']; ?>" class="<?php echo $user['status'] == 1 ? 'deactivate' : ''; ?>"  style="border:1px solid black; color:black; text-decoration:none;" >
                                <?php echo $user['status'] == 1 ? 'Deactivate' : 'Activate'; ?>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
    
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<?php require "footer.php"; ?>
    
</body>
</html>
