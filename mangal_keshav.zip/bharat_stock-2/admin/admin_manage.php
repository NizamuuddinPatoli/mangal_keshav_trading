<?php
session_start();
require '../classes/Database.php';
require '../classes/User.php';

if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'admin') {
    header('Location: ../logout.php');
    exit();
}

$database = new Database();
$conn = $database->connDb();

$user_id = $_SESSION['user_id'];
$activeuser = User::getByAdmin($conn, $user_id);

// Fetch all admins except the logged-in admin
$query = "SELECT `id`, `name`, `email`, `password` FROM `admin` WHERE `id` != ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $admins = $result->fetch_all(MYSQLI_ASSOC);
} else {
    $admins = [];
}

// Handle delete operation
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $deleteQuery = "DELETE FROM `admin` WHERE `id` = ?";
    $stmt = $conn->prepare($deleteQuery);
    $stmt->bind_param("i", $delete_id);
    $stmt->execute();
    header("Location: admin_manage.php"); // Redirect to refresh the list
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Management</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/js/all.min.js">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    
    
  
</head>
<body style="background:#fff;">

<?php require "nav-bar.php"; ?>




<div class="container mb-5" style="margin-top:100px;">

    <div class="row justify-content-center">
    
 
                        
        <div class="col-md-6 mb-5">
        <div class="row">
                        <div class="col text-center mb-2">
                            <h1 style="  text-shadow: 1px 1px 1px black, 3px 3px 5px black;">Manage Admins</h1>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col mb-3">
                        <a href="admin_add.php" class="add-admin btn btn-dark" style=" padding:10px;">Add New Admin</a>
                        </div>
                    </div>

            <div class="row ">
                <div class="col">
                    <table style="box-shadow: rgba(0, 0, 0, 0.56) 0px 22px 70px 4px; text-align:center;border-radius:10px;">
                        <thead style="border:1px solid gray; ">
                        <tr>
      <th scope="col" style="border:1px solid gray; padding:15px; width:180px;">ID</th>
      <th scope="col" style="border:1px solid gray; padding:15px; width:180px;">Name</th>
      <th scope="col" style="border:1px solid gray; padding:15px; width:180px;">Email</th>
      <th scope="col" style="border:1px solid gray; padding:15px; width:180px;">Actions</th>
    </tr>
                        </thead>
                        <tbody style="border:1px solid gray;">
                        <?php if (count($admins) > 0): ?>
                    <?php foreach ($admins as $admin): ?>
                        <tr>
                            <td style="border:1px solid gray; padding:15px; "><?php echo htmlspecialchars($admin['id']); ?></td>
                            <td style="border:1px solid gray; padding:15px; "><?php echo htmlspecialchars($admin['name']); ?></td>
                            <td style="border:1px solid gray; padding:10px; "><?php echo htmlspecialchars($admin['email']); ?></td>
                            <td class="actions">
                                <a href="admin_edit.php?id=<?php echo $admin['id']; ?>"  class="btn btn-dark" style="font-size:15px;  border:1px solid black;padding:8px; border-radius:12px; ">Edit</a>
                                <a href="admin_manage.php?delete_id=<?php echo $admin['id']; ?>" onclick="return confirm('Are you sure you want to delete this admin?');"  class="btn btn-dark"  style="font-size:15px;  border:1px solid black; padding:8px; border-radius:12px;">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4">No admins found.</td>
                    </tr>
                <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>



    


<?php require "footer.php"; ?>


      
    
</body>
</html>
