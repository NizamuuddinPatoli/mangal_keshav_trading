<?php
session_start();
require '../classes/Database.php';
require '../classes/User.php';

if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'admin') {
    header('Location: ../logout.php');
    exit();
}

$database = new Database();
$conn = $database->connDb();

if (isset($_GET['id'])) {
    $admin_id = $_GET['id'];

    // Fetch the admin details
    $query = "SELECT `id`, `name`, `email` FROM `admin` WHERE `id` = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $admin_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $admin = $result->fetch_assoc();

    if (!$admin) {
        die("Admin not found.");
    }
} else {
    die("Invalid request.");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    
    // Update admin details
    $updateQuery = "UPDATE `admin` SET `name` = ?, `email` = ? WHERE `id` = ?";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("ssi", $name, $email, $admin_id);
    if ($stmt->execute()) {
        header("Location: admin_manage.php");
        exit();
    } else {
        $error = "Failed to update admin details.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/js/all.min.js">
  
</head>
<body style="background:#fff;">
<?php require "nav-bar.php"; ?>

                
          
<div class="container mb-5">
   <h1 class="text-center" style="margin-top:90px;  text-shadow: 1px 1px 1px black, 3px 3px 5px black;">Edit Admin</h1>
    <div class="row justify-content-center" >
        <div class="col-md-5" >
            

    <form  method="POST" action="" style=" margin-top:70px; margin-bottom:50px; border:1px solid black; border-radius:30px; padding:20px; box-shadow: rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px;">


    <div class="mb-3">
<p><label for="" class="form-label" >Name</label></p>
<input  type="text" id="name" name="name" value="<?php echo htmlspecialchars($admin['name']); ?>" required  style="border-radius:15px; margin-bottom:20px; width:348px; border:1px solid gray; padding:5px;">

</div>

<div class="mb-3">
<p><label for="exampleInputEmail1" class="form-label">Email address</label></p>
<input   type="email" id="email" name="email" value="<?php echo htmlspecialchars($admin['email']); ?>" required style="border-radius:15px; margin-bottom:20px; width:348px; border:1px solid gray; padding:5px;">

</div>
<div class="form-group">

            <input type="submit" class="btn btn-dark" value="Update Admin" style="box-shadow:2px 2px 5px 5px black;">
</div>       




</form>
<?php if (isset($error)) { echo "<p style='color:red;'>$error</p>"; } ?>
        </div>
    </div>
   </div>


   <?php require "footer.php"; ?>
    
</body>
</html>
