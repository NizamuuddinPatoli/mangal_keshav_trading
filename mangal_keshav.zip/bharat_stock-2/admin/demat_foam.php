<?php
require '../classes/Database.php';
require '../classes/Demat.php';

$error = "";
$email = "";
$user = "";

// Check if ID is provided in the URL
if (isset($_GET['id'])) {
    $user_id = $_GET['id'];  // Missing semicolon fixed

    // Create a new Database connection
    $database = new Database();
    $conn = $database->connDb();

    // Fetch user data by ID
    $user = Demat::getById($conn, $user_id);  // Assuming this method fetches user data based on user ID
    if ($user) {
        $email = $user['email'];
    } else {
        $error = "User not found.";
    }

    // SQL Query to get data from `demat` table based on user ID
    $dematQuery = "SELECT `id`, `name`, `email`, `password`, `phone`, `gender`, `pan`, `dob`, `adhar_no`, `status`, `otp`, `reset_token`, `email_verified`, `verification_token`, `otp_expiry`, `code`, `file` FROM `demat` WHERE `id` = ?";
    $dematStmt = $conn->prepare($dematQuery);
    $dematStmt->bind_param("i", $user_id);  // Bind the user ID, not email
    $dematStmt->execute();
    $dematResult = $dematStmt->get_result();

    // Fetch demat data
    if ($dematResult->num_rows > 0) {
        $dematData = $dematResult->fetch_assoc();
    } else {
        $error = "No data found in the `demat` table for this user.";
    }

    // SQL Query to get data from `doc` table based on email
    $docQuery = "SELECT `id`, `email`, `file`, `sign` FROM `doc` WHERE `email` = ?";
    $docStmt = $conn->prepare($docQuery);
    $docStmt->bind_param("s", $email);  // Bind the email to fetch documents
    $docStmt->execute();
    $docResult = $docStmt->get_result();

    // Fetch doc data
    if ($docResult->num_rows > 0) {
        $docData = $docResult->fetch_assoc();
    } else {
        $error = "No data found in the `doc` table for this email.";
    }

    // Close the connection
    $conn->close();
} else {
    $error = "User ID parameter is missing.";
}
    if ($user['status'] ==1 ){
                                 $msg="email verified";
                        } elseif ($user['status'] == 'inactive' ){
                            $msg="email not verified";
                        } else{
                            $msg=' user active';
                        }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Data for <?php echo htmlspecialchars($email); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/js/all.min.js">
   
</head>
<body style="background:#fff;">
   


    
<img src="../image/MAngal-KEshav-logo.png" class="rounded mx-auto d-block" alt="...">


    
<div class="container box-shadow " style="background:#fff;  border-radius:50px;   ">
                  <h1 class="text-center " style="margin-top:30px; text-shadow: 1px 1px 1px black, 5px 5px 7px black;">Demat Information</h1>
         

                    <div class="row justify-content-center " >
                        <div class="col-md-5 p-4" style="border-radius:30px; border:1px solid black; margin-top:50px; margin-bottom:60px; box-shadow: rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px; ">
                        <?php if (!empty($error)) { ?>
        <p class="error"><?php echo $error; ?></p>
    <?php } else { ?>
                        <form action="" method="POST">
                        <div class="col">
                        <label>ID:</label>
                        <input type="text" value="<?php echo $dematData['id']; ?>" readonly style="width:400px; margin-bottom:10px;">
  <div class="mb-3">
 
  <label>Name:</label>
            <input type="text" value="<?php echo $dematData['name']; ?>" readonly style="width:373px;">

  </div>
  <div class="mb-3">
  
  <label>Email:</label>
            <input type="email" value="<?php echo $dematData['email']; ?>" readonly style="width:374px;">

  </div>
  <div class="mb-3">
  <label>Phone:</label>
            <input type="text" value="<?php echo $dematData['phone']; ?>" readonly style="width:370px;">
  </div>
  <div class="mb-3">
  <label>Gender:</label>
            <input type="text" value="<?php echo $dematData['gender']; ?>" readonly style="width:360px;">

  </div>
  <div class="mb-3">
  <label>PAN:</label>
  <input type="text" value="<?php echo $dematData['pan']; ?>" readonly style="width:378px; margin-bottom:7px;">
  <div class="mb-3">
  
  <label>DOB:</label>
            <input type="date" value="<?php echo $dematData['dob']; ?>" readonly style="width:374px;">
  </div>
  <div class="mb-3">
  <label>Aadhar No:</label>
            <input type="text" value="<?php echo $dematData['adhar_no']; ?>" readonly style="width:330px;">
  </div>
  <div class="mb-3">
  <label>Status:</label>
  <input type="text" value="<?php echo $msg; ?>" readonly style="width:359px;">
  </div>
  <div class="mb-3">
  
  <label>Code:</label>
  <input type="text" value="<?php echo $dematData['code']; ?>" readonly style="width:367px;">
  </div>
  <div class="mb-3">
  
  <label>Uploaded File:</label>
  <a href="../upload/<?php echo $dematData['file']; ?>" target="_blank" style="text-decoration:none; color:maroon;">View File</a>
  </div>
  

</form>
                        </div>
                    </div>
                </div>






                
<div class="container"  style="  border-radius:50px;   ">
<h1 class="text-center " style="margin-top:30px; text-shadow: 1px 1px 1px black, 5px 5px 7px black;">Document Information</h1>
    <div class="row justify-content-center">
        <div class="col-md-5 p-4"  style="border-radius:30px; border:1px solid black; margin-top:50px; margin-bottom:60px; box-shadow: rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px; ">
            <div class="row">
                <div class="col">
                <form action="" method="POST">
                       
                       <div class="mb-3">
                       <label>Uploaded Document:</label>
                       <a href="../uploads_doc/<?php echo $docData['file']; ?>" target="_blank" style="text-decoration:none; color:maroon;">View Document</a>
                       </div>
                       <div class="mb-3">
                       
                       <label>Digital Signature:</label>
                       <a href="../uploads_doc/<?php echo $docData['sign']; ?>" target="_blank" style="text-decoration:none; color:maroon;">View Signature</a>
                                 </div>
                       </div>
                       
                       </div>
                       
                     
                       
                     </form>
                     <a href="demat_edit.php?id=<?php echo $user['id']; ?>"  style="border:1px solid black; color:maroon; text-decoration:none; border-radius:2px; padding:5px; ">Edit</a>
         <a href="demat_manage.php?delete_id=<?php echo $user['id']; ?>" onclick="return confirm('Are you sure you want to delete this user?');"  style="border:1px solid black;color:maroon; text-decoration:none; border-radius:2px; padding:5px; ">Delete</a>
         <a href="demat_manage.php?status_id=<?php echo $user['id']; ?>&status=<?php echo $user['status']; ?>" class="<?php echo $user['status'] == 1 ? 'deactivate' : ''; ?>"  style="border:1px solid black;color:maroon; text-decoration:none; border-radius:2px; padding:5px; " >
        <?php echo $user['status'] == 'active' ? 'Deactivate' : 'Activate'; ?>
                            </a>

        
    <?php } ?>
                   
                </div>
            </div>
        </div>
    </div>
</div>

    


</body>
</html>

