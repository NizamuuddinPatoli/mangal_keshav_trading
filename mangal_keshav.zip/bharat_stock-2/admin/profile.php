<?php
session_start();
require '../classes/Database.php';
require '../classes/User.php';

if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'admin') {
    header('Location: ../logout.php');
    exit();
}

$database = new Database();
$conn = $database->connDb();

$user_id = $_SESSION['user_id'];
$activeuser = User::getByAdmin($conn, $user_id);  // Assuming this method fetches admin data based on user ID
$userName = $activeuser['name'];
$userEmail = $activeuser['email'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newPassword = $_POST['new_password'];
    $confirmPassword = $_POST['confirm_password'];

    if ($newPassword === $confirmPassword) {
        $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);
        $stmt = $conn->prepare("UPDATE admin SET password = ? WHERE id = ?");
        $stmt->bind_param('si', $hashedPassword, $user_id);

        if ($stmt->execute()) {
            $successMessage = "Password updated successfully.";
        } else {
            $errorMessage = "Failed to update password. Please try again.";
        }

        $stmt->close();
    } else {
        $errorMessage = "Passwords do not match. Please try again.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - Barat Stock Trading</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/js/all.min.js">
</head>
 
<body style="background:#fff;">

<?php require "nav-bar.php"; ?>




<div class="container box-shadow " style="background:#fff;  border-radius:50px;   ">
                  <h1 class="text-center " style="margin-top:30px; text-shadow: 1px 1px 1px black, 5px 5px 7px black;">Admin</h1>
                    
        <?php if (isset($successMessage)) { echo "<p style='color: green;'>$successMessage</p>"; } ?>
        <?php if (isset($errorMessage)) { echo "<p style='color: red;'>$errorMessage</p>"; } ?>

                    <div class="row justify-content-center " >
                        <div class="col-md-5 p-4" style="border-radius:30px; border:1px solid black; margin-top:50px; margin-bottom:60px; box-shadow: rgba(0, 0, 0, 0.25) 0px 54px 55px, rgba(0, 0, 0, 0.12) 0px -12px 30px, rgba(0, 0, 0, 0.12) 0px 4px 6px, rgba(0, 0, 0, 0.17) 0px 12px 13px, rgba(0, 0, 0, 0.09) 0px -3px 5px; ">
                        <form action="profile.php" method="POST">
                        <div class="col">
    <input type="text" class="form-control" placeholder="First name" aria-label="First name" type="text" id="name" name="name" value="<?php echo htmlspecialchars($userName); ?>" readonly>
  </div>
  <div class="mb-3">
    <!-- <label for="exampleInputEmail1" class="form-label">Email address</label> -->
    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Email address" style="margin-top:10px;" type="email" id="email" name="email" value="<?php echo htmlspecialchars($userEmail); ?>" readonly  >
 
  </div>
  <div class="mb-3">
    <!-- <label for="exampleInputPassword1" class="form-label">Password</label> -->
    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="New Password" type="password" id="new_password" name="new_password" required >
  </div>
  <div class="mb-3">
    <!-- <label for="exampleInputPassword1" class="form-label">Password</label> -->
    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Confirm Password" type="password" id="confirm_password" name="confirm_password" required>
  </div>
  

  <div class="form-group">
                <button type="submit" class="btn btn-dark" style="border-radius:10px;  box-shadow:2px 2px 5px 5px black;">Update Password</button>
            </div>
</form>
                        </div>
                    </div>
                </div>
   

     
<?php require "footer.php"; ?>
    
</body>
</html>
