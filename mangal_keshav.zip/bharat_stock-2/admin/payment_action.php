<?php
session_start();
require '../classes/Database.php';
require '../classes/User.php';

if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'admin') {
    header('Location: ../logout.php');
    exit();
}
if (!isset($_GET['action']) || !isset($_GET['id'])) {
    header('Location: payment_manage.php');
    exit();
}

$database = new Database();
$conn = $database->connDb();

$action = $_GET['action'];
$payment_id = $_GET['id'];

if ($action === 'approve') {
    $status = 'approved';
} elseif ($action === 'reject') {
    $status = 'rejected';
} else {
    header('Location: payment_manage.php');
    exit();
}

// Update payment status
$sql = "UPDATE payment SET status = ? WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("si", $status, $payment_id);

if ($stmt->execute()) {
    $_SESSION['message'] = "Payment status updated successfully.";
} else {
    $_SESSION['message'] = "Error updating payment status.";
}

header('Location: payment_manage.php');
exit();
?>
