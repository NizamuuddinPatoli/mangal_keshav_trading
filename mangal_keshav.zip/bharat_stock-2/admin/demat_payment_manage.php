<?php
session_start();
require '../classes/Database.php';
require '../classes/User.php';
require '../classes/Demat.php';

// Check if the user is an admin
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'admin') {
    header('Location: ../logout.php');
    exit();
}

// Database connection
$database = new Database();
$conn = $database->connDb();

// Fetch payment records along with user information from demat table
$sql = "SELECT p.id, p.dop, p.bank, p.file, p.status, d.name, d.email 
        FROM d_payment p 
        JOIN demat d ON p.demat_id = d.id";
$result = $conn->query($sql);

// Check for SQL query errors
if ($result === false) {
    die("SQL Error: " . $conn->error);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Manage Demat Payments</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" defer></script>
</head>
<body>

<?php require "nav-bar.php"; ?>

<div class="container" style="margin-top:100px;">
    <h1 style="text-shadow: 1px 1px 1px black, 3px 3px 5px black; text-align:center;">Manage Demat Payments</h1>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <table class="table table-bordered table-striped" style="box-shadow: rgba(0, 0, 0, 0.56) 0px 22px 70px 4px; text-align:center;">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>User Name</th>
                        <th>User Email</th>
                        <th>Date of Payment</th>
                        <th>Bank</th>
                        <th>Screenshot</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['dop']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['bank']) . "</td>";
                            echo "<td><a href='../upload/" . htmlspecialchars($row['file']) . "' target='_blank'>View Screenshot</a></td>";
                            echo "<td>" . htmlspecialchars($row['status']) . "</td>";
                            
                            // Display Approve/Reject buttons if status is pending
                            if ($row['status'] === 'pending') {
                                echo "<td>
                                        <a href='demat_payment_action.php?action=approve&id=" . htmlspecialchars($row['id']) . "' class='btn btn-dark btn-sm'>Approve</a>
                                        <a href='demat_payment_action.php?action=reject&id=" . htmlspecialchars($row['id']) . "' class='btn btn-danger btn-sm'>Reject</a>
                                      </td>";
                            } else {
                                echo "<td>" . ucfirst($row['status']) . "</td>"; // Display status if already approved/rejected
                            }

                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='8'>No payment records found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require "footer.php"; ?>

</body>
</html>
