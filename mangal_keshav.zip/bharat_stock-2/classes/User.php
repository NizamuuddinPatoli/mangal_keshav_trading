<?php

class User 
{
    public $name;
    public $email;
    public $password;
    public $dob;
    public $phone;
    public $status = 1; // Default status

 
    public function createOne($conn)
    {
        // SQL query
        $query = "INSERT INTO users (name, email, password, dob, phone, status) VALUES (?, ?, ?, ?, ?, ?)";

        // Prepare statement
        $stmt = mysqli_prepare($conn, $query);

        if (!$stmt) {
            // Error preparing the statement
            return "Error preparing statement: " . mysqli_error($conn);
        }

        // Bind parameters
        mysqli_stmt_bind_param($stmt, 'sssssi', $this->name, $this->email, $this->password, $this->dob, $this->phone, $this->status);

        // Execute statement
        if (mysqli_stmt_execute($stmt)) {
            return true;
        } else {
            return "Error executing statement: " . mysqli_stmt_error($stmt);
        }
    }
public static function getById($conn , $id){
        $query = "SELECT * FROM users WHERE id = ?";
        $stmt = mysqli_prepare( $conn , $query );
        mysqli_stmt_bind_param( $stmt , 'i' , $id );
        if ( mysqli_stmt_execute( $stmt ) ){
            $result = mysqli_stmt_get_result( $stmt );
            return mysqli_fetch_assoc( $result );
        }
    }

    public static function getByAdmin($conn , $id){
        $query = "SELECT * FROM admin WHERE id = ?";
        $stmt = mysqli_prepare( $conn , $query );
        mysqli_stmt_bind_param( $stmt , 'i' , $id );
        if ( mysqli_stmt_execute( $stmt ) ){
            $result = mysqli_stmt_get_result( $stmt );
            return mysqli_fetch_assoc( $result );
        }
    }


public function authenticate($conn, $email, $password)
    {
        // Check if the user is an admin
        $query = "SELECT id, name, email, password FROM admin WHERE email = ?";
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, 's', $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($row = mysqli_fetch_assoc($result)) {
            if (password_verify($password, $row['password'])) {
                // Start session and set admin session variables
                session_start();
                $_SESSION['user_id'] = $row['id'];
                $_SESSION['email'] = $row['email'];
                $_SESSION['user_type'] = 'admin'; // Distinguish admin
                return true;
            }
        }

        // Check if the user is a regular user
        $query = "SELECT id, name, email, password, status FROM users WHERE email = ?";
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, 's', $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($row = mysqli_fetch_assoc($result)) {
            if (password_verify($password, $row['password'])) {
                if ($row['status'] == 1) { // Check if the user is active
                    // Start session and set user session variables
                    session_start();
                    $_SESSION['user_id'] = $row['id'];
                    $_SESSION['email'] = $row['email'];
                    $_SESSION['user_type'] = 'user'; // Distinguish regular user
                    return true;
                } else {
                    return "inactive";
                }
            }
        }

        // If no match found
        return false;
    }

    // Authenticate user or admin
    public static function authentication($conn, $email) {
          $sql = "SELECT * FROM users WHERE email = ?";
    $stmt = mysqli_prepare($conn, $sql);

    mysqli_stmt_bind_param($stmt, 's', $email);

    if (mysqli_stmt_execute($stmt)) {
        $data = mysqli_stmt_get_result($stmt);
        return mysqli_fetch_assoc($data);
    }
}

public static function storeOTP($conn, $email, $otp) {
    $sql = "UPDATE users SET otp = ? WHERE email = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("ss", $otp, $email);
    $stmt->execute();
    $stmt->close();
}

public static function verifyOTP($conn, $email, $otp) {
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND otp = ?");
    if (!$stmt) {
        die('Prepare failed: (' . $conn->errno . ') ' . $conn->error);
    }
    $stmt->bind_param('ss', $email, $otp);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        return $result->fetch_assoc();
    } else {
        return false;
    }
}


    public static function verifyResetToken($conn, $email, $token) {
        // Verify the reset token against the stored value in the database
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? ");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            return $result->fetch_assoc();
        } else {
            return false;
        }
    }

public static function updatePassword($conn, $email, $hashedPassword) {
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
    if ($stmt === false) {
        error_log('MySQL Prepare failed: ' . $conn->error);
        return false;
    }
    $stmt->bind_param('ss', $hashedPassword, $email);
    return $stmt->execute();
}
}
