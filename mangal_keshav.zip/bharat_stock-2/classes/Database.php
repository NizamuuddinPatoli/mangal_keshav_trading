<?php 

class Database
{
    public $hostname = 'localhost';
    public $databaseUser = 'root';
    public $databasePass = '';
    public $databaseName = 'barat_trading';

    public function connDb() {
        $conn = mysqli_connect($this->hostname, $this->databaseUser, $this->databasePass, $this->databaseName);
        
        if (mysqli_connect_errno()) {
            die("Failed to connect to MySQL: " . mysqli_connect_error());
        }
        
        return $conn;
    }
}
?>
