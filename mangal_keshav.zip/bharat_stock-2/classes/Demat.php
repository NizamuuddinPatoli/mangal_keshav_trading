<?php

class Demat {
    // User properties
    public $id;
    public $name;
    public $email;
    public $password;
    public $dob;
    public $phone;
    public $gender;
    public $pan;
    public $adhar_no;
    public $status = 'inactive'; // Default status to 'inactive' until verified

    // Constructor (if needed)
    public function __construct() {
        // You can initialize any default values or logic here if needed
    }
      public static function authentication($conn, $email) {
        $stmt = $conn->prepare("SELECT `email`, `name`, `password`, `dob`, `phone`, `adhar_no`, `pan`, `gender` FROM `demat` WHERE `email` = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $data = $result->fetch_assoc();
        $stmt->close();
        return $data;
    }

    // Method to create a new user in the database
    public function createOne($conn) {
        // Prepare the SQL statement to insert user data into the `demat` table
        $stmt = $conn->prepare("
            INSERT INTO demat (name, email, password, dob, phone, gender, pan, adhar_no, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        // Check if the prepare statement was successful
        if ($stmt === false) {
            // Log or print error (for debugging)
            die("Error preparing the statement: " . $conn->error);
        }

        // Bind the parameters (s = string, etc.)
        $stmt->bind_param("sssssssss", $this->name, $this->email, $this->password, $this->dob, $this->phone, $this->gender, $this->pan, $this->adhar_no, $this->status);

        // Execute the query and check for success
        if ($stmt->execute()) {
            return true;
        } else {
            // Return the error message in case of failure
            return $stmt->error;
        }

        // Close the statement
        $stmt->close();
    }
    public static function getByAdmin($conn , $id){
        $query = "SELECT * FROM admin WHERE id = ?";
        $stmt = mysqli_prepare( $conn , $query );
        mysqli_stmt_bind_param( $stmt , 'i' , $id );
        if ( mysqli_stmt_execute( $stmt ) ){
            $result = mysqli_stmt_get_result( $stmt );
            return mysqli_fetch_assoc( $result );
        }
    }
    // Method to verify user status (based on email, for example)
    public function verifyEmail($conn, $email) {
        $stmt = $conn->prepare("
            SELECT id, name, email, status FROM demat WHERE email = ?
        ");

        if ($stmt === false) {
            die("Error preparing the statement: " . $conn->error);
        }

        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        // If the user is found, return the result
        if ($result->num_rows > 0) {
            return $result->fetch_assoc(); // Return user details as an associative array
        } else {
            return false; // Return false if the email is not found
        }

        $stmt->close();
    }
    
    public function getUserStatusById($conn, $userId) {
        $query = "SELECT status FROM demat WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $stmt->bind_result($status);
        $stmt->fetch();
        $stmt->close();

        return $status !== null ? $status : 'inactive'; // Return status or 'inactive' if not found
    }

    
    // Method to update the user's status to 'active'
    public function activateUser($conn, $email) {
        $stmt = $conn->prepare("
            UPDATE demat SET status = 'active' WHERE email = ?
        ");

        if ($stmt === false) {
            die("Error preparing the statement: " . $conn->error);
        }

        $stmt->bind_param("s", $email);

        if ($stmt->execute()) {
            return true;
        } else {
            return $stmt->error;
        }

        $stmt->close();
    }
   
 public function authenticate($conn, $email, $password) {
    $query = "SELECT password, status FROM demat WHERE email = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($hashedPassword, $status);
    
    if ($stmt->num_rows == 1) {
        $stmt->fetch();
        // var_dump($hashedPassword); // Debugging: Output the hashed password
        // var_dump(password_verify($password, $hashedPassword)); // Debugging: Check password verification
        if (password_verify($password, $hashedPassword)) {
            return $status; // Return status if password is correct
        }
    }
    return false; // Return false if authentication fails
}

public static function getById($conn, $id) {
    $query = "SELECT * FROM demat WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 'i', $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if ($row = mysqli_fetch_assoc($result)) {
        return $row; // Return the user data
    }
    return null; // Return null if no user found
}
public function getUserIdByEmail($conn, $email) {
    $query = "SELECT id FROM demat WHERE email = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 's', $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    
    if ($row = mysqli_fetch_assoc($result)) {
        return $row['id'];
    }
    return null; // Return null if no user ID found
}


    public static function storeOTP($conn, $email, $otp) {
    $sql = "UPDATE demat SET otp = ? WHERE email = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("ss", $otp, $email);
    $stmt->execute();
    $stmt->close();
}

public static function verifyOTP($conn, $email, $otp) {
    $stmt = $conn->prepare("SELECT * FROM demat WHERE email = ? AND otp = ?");
    if (!$stmt) {
        die('Prepare failed: (' . $conn->errno . ') ' . $conn->error);
    }
    $stmt->bind_param('ss', $email, $otp);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        return $result->fetch_assoc();
    } else {
        return false;
    }
}


    public static function verifyResetToken($conn, $email, $token) {
        // Verify the reset token against the stored value in the database
        $stmt = $conn->prepare("SELECT * FROM demat WHERE email = ? ");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            return $result->fetch_assoc();
        } else {
            return false;
        }
    }

public static function updatePassword($conn, $email, $hashedPassword) {
    $stmt = $conn->prepare("UPDATE demat SET password = ? WHERE email = ?");
    if ($stmt === false) {
        error_log('MySQL Prepare failed: ' . $conn->error);
        return false;
    }
    $stmt->bind_param('ss', $hashedPassword, $email);
    return $stmt->execute();
}
}

?>
