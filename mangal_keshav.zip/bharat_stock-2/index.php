<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barat Stock Trading</title>
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/js/all.min.js">
</head>
<body>
  <!-- <header>
    <div class="header-container">
        <div class="logo-container">
            <img src="image/Bharatlogo-01.png" alt="logo" class="logo">
        </div>
            <h1 class="title-nav">Barat Stock Trading</h1>

        <div class="title-nav nav-active" role="navigation" aria-label="main navigation">
            <ul class="navbar-links">
                <li class="hide-on-small"><a href="signup.php">Sign Up</a></li>
                <li class="hide-on-small"><a href="#">About</a></li>
                <li class="hide-on-small"><a href="#">Products</a></li>
                <li class="hide-on-small"><a href="#">Pricing</a></li>
                <li class="hide-on-small"><a href="#">Support</a></li>
                <li id="navbar_menu">
                    <div class="cursor-pointer" id="menu_btn" title="Menu">
                        <div id="nav-icon3">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</header>

        

<div class="center-image">
    <img src="image/new.png" alt="Centered Image">
</div>

<h1 class="center-text">INVEST EVERY THING </h1>
<h3 class="center-text">Online platform to invest in stocks, derivatives, mutual funds, ETFs, bonds, and more.</h3>

    <main>
        <section class="chart-container">
            <h2>Market Overview</h2>
            <div class="chart-wrapper">
                <canvas id="lineChart"></canvas>
            </div>
            <div class="chart-wrapper">
                <canvas id="barChart"></canvas>
            </div>
        </section>
        <section class="chart-container">
        <img src="image/Stock_Market_Trading.mp4" alt="video">
</section>
        <section class="image-content">
            <div class="shape-container">
                <div class="square">
                    <img src="image/Logo-02.png" alt="Square Image" class="content-image">
                </div>
                <div class="content">
                    <h3>Invest with Confidence</h3>
                    <p>Our platform provides comprehensive tools and analytics to help you make informed trading decisions.</p>
                </div>
            </div>
        </section>
    </main>
<br>
<br>
    <footer>
        <p>&copy; 2024 Barat Stock Trading. All rights reserved.</p>
    </footer> -->

    <div class="container">
        <div class="row">
            <div class="col-md-2">
                <img src="image/MAngal-KEshav-logo.png" class="card-img-top" alt="..." style="overflow-clip-margin: content-box;
    overflow: clip;vertical-align: middle;
    border-style: none;max-width: 100%;
    height: auto;margin: 0;    max-height: 150px;padding: 5px 0px;
        position: relative;
        top: unset;">
            </div>
            <div class="col-md-10">
                <div class="row">
                    <ul class="nav justify-content-center">
                        <li class="nav-item">
                          <a class="nav-link active" aria-current="page" href="#" style="color: #5c768d;padding: 8px 18px;
    line-height: unset;display: inline-block;">About Us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="#" style="color: #5c768d;padding: 8px 18px;
    line-height: unset;display: inline-block;">Careers</a>
                          </li>
                        <li class="nav-item">
                          <a class="nav-link" href="#" style="color: #5c768d;padding: 8px 18px;
    line-height: unset;display: inline-block;">Videos</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="#" style="color: #5c768d;padding: 8px 18px;
    line-height: unset;display: inline-block;">Re-KYC</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link disabled" aria-disabled="true" style="color: #5c768d;padding: 8px 18px;
    line-height: unset;display: inline-block;"> <i class="fa-solid fa-phone"></i> +91 22 6190 8000</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle"  href="login.php"  aria-expanded="false" style="color: #5c768d;padding: 8px 18px;
    line-height: unset;display: inline-block;">Login</a>
  
                            <ul class="dropdown-menu">
                              <li><a class="dropdown-item" href="#">Action</a></li>
                              <li><a class="dropdown-item" href="#">Another action</a></li>
                              <li><a class="dropdown-item" href="#">Something else here</a></li>
                              <li><hr class="dropdown-divider"></li>
                              <li><a class="dropdown-item" href="#">Separated link</a></li>
                            </ul>
                          </li>
                          <form class="d-flex" role="search">
                            <a href="" type="button" class="btn btn-outline-danger" style="margin-top: 5px;">Open an Account</a>
                        
                            <!-- <button type="button" class="btn btn-outline-danger" style="margin-top: 5px;">Open an Account</button> -->
                          </form>
                      </ul>
                </div>
                <hr>
                <div class="row sticky-top">
                    <ul class="nav justify-content-center sticky-top">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false" style="color: #5c768d;padding: 8px 18px;
    line-height: unset;display: inline-block;">Products</a>
                            <ul class="dropdown-menu">
                              <li><a class="dropdown-item" href="#">Action</a></li>
                              <li><a class="dropdown-item" href="#">Another action</a></li>
                              <li><a class="dropdown-item" href="#">Something else here</a></li>
                              <li><hr class="dropdown-divider"></li>
                              <li><a class="dropdown-item" href="#">Separated link</a></li>
                            </ul>
                          </li>
                          <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false" style="color: #5c768d;padding: 8px 18px;
    line-height: unset;display: inline-block;">Services</a>
                            <ul class="dropdown-menu">
                              <li><a class="dropdown-item" href="#">Action</a></li>
                              <li><a class="dropdown-item" href="#">Another action</a></li>
                              <li><a class="dropdown-item" href="#">Something else here</a></li>
                              <li><hr class="dropdown-divider"></li>
                              <li><a class="dropdown-item" href="#">Separated link</a></li>
                            </ul>
                          </li>
                        <li class="nav-item">
                          <a class="nav-link active" aria-current="page" href="#" style="color: #5c768d;padding: 8px 18px;
    line-height: unset;display: inline-block;">Pledge</a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="#" style="color: #5c768d;padding: 8px 18px;
    line-height: unset;display: inline-block;">Blogs</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false" style="color: #5c768d;padding: 8px 18px;
    line-height: unset;display: inline-block;">Knowledge Panel</a>
                            <ul class="dropdown-menu">
                              <li><a class="dropdown-item" href="#">Action</a></li>
                              <li><a class="dropdown-item" href="#">Another action</a></li>
                              <li><a class="dropdown-item" href="#">Something else here</a></li>
                              <li><hr class="dropdown-divider"></li>
                              <li><a class="dropdown-item" href="#">Separated link</a></li>
                            </ul>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="#" style="color: #5c768d;padding: 8px 18px;
    line-height: unset;display: inline-block;">Contact us</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="#" style="color: #B30001;
    text-decoration: underline;font-size: 13px;padding: 14px 16px; font-size: 13px;">Become a sub broker</a>
                          </li>
                      </ul>
                </div>
            </div>
        </div>
    </div>

    





      <div id="carouselExampleCaptions" class="carousel slide">
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="image/OIP-5.jpeg" class="d-block w-100" alt="..." style="height: 350px ; opacity: 0.7;  ">
            <div class="carousel-caption d-none d-md-block"  style="position: absolute; width: 50%; top: 2%; left: 0; margin-left: 15%; text-align: left;">
              <h2  style="font-size: 5em; color: #000;
              font-size: 30px;
              font-weight: 600;color: #000;
  font-size: 30px;
  font-weight: 600;display: block;
  text-align: left;
  margin-block-start: 0.83em;
  margin-block-end: 0.83em;
  margin-inline-start: 0px;
  margin-inline-end: 0px;
  
  unicode-bidi: isolate;" >India’s Leading Stock Broking Company</h2>
              <p  style="color: #B30001;
              font-size: 25px;
              font-weight: 400;animation-delay: 0.4s;width: 80%;
                " >Nurturing Wealth since 1939</p>
                <a href="demat/signup.php">
                  <button type="button" class="btn btn-outline-success" style="background-image: linear-gradient(#B30001, #660000);
                  font-size: 18px;
                  padding: 14px 20px;
                  margin-left: 0px;font-weight: 500;
                  letter-spacing: 1px;
                  display: inline-block; border-radius: 5px;
      transition: 0.5s;
      line-height: 1;
      margin: 10px;
      color: #fff; ">Open free* Demat Account</button>
      </a>
            </div>
          </div>
          <div class="carousel-item">
            <img src="image/istockphoto-499195831-612x612.jpg" class="d-block w-100" alt="..." style="height: 350px;  opacity:0.6;">
            <div class="carousel-caption d-none d-md-block"  style="position: absolute; width: 50%; top: 2%; left: 0; margin-left: 15%; text-align: left;">
              <h2   style="font-size: 5em; color: #000;
              font-size: 30px;
              font-weight: 600;color: #000;
  font-size: 30px;
  font-weight: 600;display: block;
  text-align: left;
  margin-block-start: 0.83em;
  margin-block-end: 0.83em;
  margin-inline-start: 0px;
  margin-inline-end: 0px;
  
  unicode-bidi: isolate;" >Mangal Keshav Investment Advisory Services</h2>
              <p  style="color: #B30001;
              font-size: 25px;
              font-weight: 400;animation-delay: 0.4s;width: 80%;
                "  >SEBI Registered</p>

<button type="button" class="btn btn-outline-success" style="background-image: linear-gradient(#B30001, #660000);
font-size: 18px;
padding: 14px 20px;
margin-left: 0px;font-weight: 500;
letter-spacing: 1px;
display: inline-block; border-radius: 5px;
transition: 0.5s;
line-height: 1;
margin: 10px;
color: #fff;                ">Learn More</button>
            </div>
          </div>
        
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>



      <div class="container mt-5  mb-5">
        <div class="row">
          <div class="col-md-5">
            <div class="row">
              <div class="col" >
                <h2 style="font-weight: 700; 
                margin-bottom: 50px;
                padding-bottom: 0;
                color: #363636; font-size: 34px;">Reasons to choose <span style="color: #B30001;"> Mangal Keshav </span></h2>
              </div>
            </div>
            <div class="row">
              <div class="col">
                
                <p>
                  <i class="fa-solid fa-check-double" style="color: #B30001;"></i>
                  Member of stock exchanges since 1939</p>
              </div>
            </div>
            <div class="row">
              <div class="col">
                <p>  <i class="fa-solid fa-check-double" style="color: #B30001;"></i> Our service is based on high level of professionalism and integrity</p>
              </div>
            </div>
            <div class="row">
              <div class="col">
                <p>  <i class="fa-solid fa-check-double" style="color: #B30001;"></i> We believe in personal investment management, thus offer you a tailor-made investment solution</p>
              </div>
            </div>
            <div class="row">
              <div class="col">
                <p>  <i class="fa-solid fa-check-double" style="color: #B30001;"></i> Our core values revolve around client investment needs and objectives</p>
              </div>
            </div>
            <div class="row">
              <div class="col">
                <p>  <i class="fa-solid fa-check-double" style="color: #B30001;"></i> We offer competitive and transparent fee structure</p>
              </div>
            </div>
            <div class="row">
              <div class="col">
                <p>  <i class="fa-solid fa-check-double" style="color: #B30001;"></i>  Our services portfolio offers wide range of products for your wealth creation</p>
              </div>
            </div>
          </div>
          <div class="col-md-6">

            <div class="row">
              <div class="col">
                <div class="row" >
                  <div class="col">
                    <img src="image/R (3).png" class="card-img-top" alt="...">
                    

                  </div>
                </div>
               
              </div>
            </div>
            <div class="row"></div>
            <div class="row"></div>
          </div>
        </div>
      </div>



      <div class="container  ">
        <div class="row">
          <div class="col-md-12 text-center">
            <div class="row">
              <div class="col">
                <small style="background-color: #B30001; color: #fff;  padding: 30px; border-radius: 7px; font-size: 25px;"> <i class="fa-solid fa-coins" ></i> Products
                
                </small>
                <small style="background-color: #fff; color: #B30001; border: 2px solid #B30001 ;  padding: 25px; font-size: 24px; border-bottom-right-radius: 25px; border-top-right-radius: 25px;">
                  <i class="fa-regular fa-clock" style="color: #B30001;"></i>  Services
                </small>
                
              </div>
             
            </div>
          </div>
        </div>
      </div>


      <div class="container-fluid pb-5 pt-5 " style="    background: #F8F8F8;">
        <div class="row">
          <div class="col-md-3 border-right mb-2" style="border-right: 1px solid #dee2e6 !important; padding-left: 50px; ">
            <div class="row mb-3 mt-5" >
              <div class="col " >
                <a href="" style="color: #B30001; font-size: 20px;text-decoration: none;
    background-color: transparent;">
                  <i class="fa-solid fa-caret-right" style="color: #B30001;"></i>
                  Equity Trading
                </a>
              </div>
            </div>
            <div class="row mb-3">
              <div class="col " >
                <a href="" style="color: #707070;
    font-size: 20px;text-decoration: none;
    background-color: transparent;">
                  <i class="fa-solid fa-caret-right" style="color: #707070;
"></i>
                  Commodity Trading
                </a>
              </div>
            </div>
            <div class="row mb-3">
              <div class="col"></div>
                <a href="" style="color: #707070;
    font-size: 20px;text-decoration: none;
    background-color: transparent;">
                  <i class="fa-solid fa-caret-right" style="color: #707070;
"></i>
                  Currency Trading
                </a>
              </div>
              <div class="row mb-3">
                <div class="col"></div>
                  <a href="" style="color: #707070;
      font-size: 20px;text-decoration: none;
      background-color: transparent;">
                    <i class="fa-solid fa-caret-right" style="color: #707070;
  "></i>
                    Derivatives Trading
                  </a>
                </div>
            </div>

            <div class="col-md-4 mt-5 " style="padding-left: 50px;">
              <div class="row">
                <div class="col">
                  <ul class="list-height" >
                    <li>
                      Well researched equity recommendations
                    </li>
                    <li>Risk based investment products</li>
                    <li>Tailormade products for investors and traders</li>
                    <li>Seamless back-office support.</li>
                    <li>Intra-day and long-term recommendations.</li>
                    <li>Market reports.</li>
                    <a href="" class="btn btn-dark" style="color: #fff;
                    background-color: #343a40;
                    border-color: #343a40;">Equity Trading</a>
                  </ul>
                  
                </div>
              </div>
            </div>
            <div class="col-md-4 mt-5">
              <div class="row">
                <div class="col">
                  <img src="image/p1.png" class="card-img-top" alt="...">

                </div>
              </div>
            </div>

            </div>
          </div>



          <div class="container mt-5 mb-5">
              <div class="row">
                <div class="col-md-12 text-center">
                     <h2>Research  
                      <span style="    color: #B30001;"> Reports </span>
                     </h2>
                </div>
              </div>
          </div>


      



          <div class="container-fluid mt-5 mb-5">
            <div class="row justify-content-evenly">
              <div class="col-md-4">
                <div class="row">
                  <div class="col"> <i class="fa-solid fa-radio" style="color: #B30001; font-size: 50px;" ></i></div>
                </div>
                <div class="row">
                  <div class="col">
                    <h3 style="font-size: 40px;color: #444;">Fundamental 
                      <br> Reports
                    </h3>
                  </div>
                </div>
                <div class="row">
                  <div class="col">
                    <a href="" style="color: #B30001; text-decoration: none;
    background-color: transparent;">  <i class="fa-solid fa-caret-right" style="color: #B30001;"></i> Company Reports</a>
                  </div>
                </div>
                <div class="row">
                  <div class="col">
                    <a href="" style="color: #B30001; text-decoration: none;
    background-color: transparent;">  <i class="fa-solid fa-caret-right" style="color: #B30001;"></i> Special Reports</a>
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <img src="image/fundamental_reports.png" alt="" style="position: relative; height: 300px; position: absolute;">
                <div class="row">
                  <div class="col">
                    <ul class="pb-5 pt-3 pl-3" style="box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px ; position:relative; background-color: #fff; border-radius: 50px; ">
                      <li>
                        Team of Highly qualified & professional Research analysts
                      </li>
                      <li>In-depth fundamental research reports</li>
                      <li>Micro to Macro economic monitoring</li>
                      <li>Robust Analytical services</li>
                      <li>Short term – long term research picks</li>
                      <li>Highest coverage of stocks</li>
                      <li> Market analysis and outlook</li>
                    </ul>
                  </div>
                </div>

              </div>
            </div>
          </div>
          </div>





          <div class="container-fluid mb-5 mt-5">
            <div class="row justify-content-evenly">
              <div class="col-md-4">
                <img src="image/technical_report.png" alt="" style="position: relative; height: 300px; position: absolute;">

                <div class="row">
                  <div class="col">
                    <ul class=" pt-5 pb-5" style="box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px; border-radius: 20px; position:relative; background-color: #fff; border-radius: 50px;">
                      <li>Team of Highly qualified & professional Research analysts</li>
                      <li>In-depth fundamental research reports</li>
                      <li>Micro to Macro economic monitoring</li>
                      <li>Robust Analytical services</li>
                      <li>Short term – long term research picks</li>
                      <li>Highest coverage of stocks</li>
                      <li>Market analysis and outlook</li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="col-md-4">
                <div class="row">
                  <div class="col">
                    <i class="fa-solid fa-radio" style="color: #B30001; font-size: 50px;" ></i>
                  </div>
                </div>
                <div class="row">
                  <div class="col">
                    <h3 style="font-size: 40px;color: #444;">Technical
                      <br> Reports
                    </h3>
                </div>
                <div class="row">
                  <div class="col"></div>
                    <a href="" style="color: #B30001; text-decoration: none;
    background-color: transparent;">  <i class="fa-solid fa-caret-right" style="color: #B30001;"></i> Daily Report</a>
                   </div>
                </div>
                <div class="row">
                  <div class="col">
                    <a href="" style="color: #B30001; text-decoration: none;
    background-color: transparent;">  <i class="fa-solid fa-caret-right" style="color: #B30001;"></i> Top Picks</a>
                  </div>
                </div>
                <div class="row">
                  <div class="col">
                    <a href="" style="color: #B30001; text-decoration: none;
    background-color: transparent;">  <i class="fa-solid fa-caret-right" style="color: #B30001;"></i> Weekly Report</a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          </div>






          <div class="container-fluid mt-5 mb-5">
            <div class="row justify-content-evenly">
              <div class="col-md-4 mt-5">
                <div class="row">
                  <div class="col">
                    <i class="fa-solid fa-radio" style="color: #B30001; font-size: 50px;" ></i>
                  </div>
                </div>
                <div class="row">
                  <div class="col">
                    <h3 style="font-size: 45px;margin-bottom: .5rem;
                    font-weight: 500;
                  color: #444;">Knowledge Panel</h3>
                  </div>
                </div>
                <div class="row">
                  <div class="col">
                    <a href="" style="color: #B30001; text-decoration: none;
    background-color: transparent;">  <i class="fa-solid fa-caret-right" style="color: #B30001;"></i> Dermat Account</a>
                  </div>
                </div>
                <div class="row">
                  <div class="col">
                    <a href="" style="color: #B30001; text-decoration: none;
    background-color: transparent;">  <i class="fa-solid fa-caret-right" style="color: #B30001;"></i> Trading Account</a>
                  </div>
                </div>
                <div class="row">
                  <div class="col">
                    <a href="" style="color: #B30001; text-decoration: none;
    background-color: transparent;">  <i class="fa-solid fa-caret-right" style="color: #B30001;"></i> Online share Trading</a>
                  </div>
                </div>
                <div class="row">
                  <div class="col">
                    <a href="" style="color: #B30001; text-decoration: none;
    background-color: transparent;">  <i class="fa-solid fa-caret-right" style="color: #B30001;"></i> Intraday Trading</a>
                  </div>      
                </div>
              </div>
              <div class="col-md-4">
                <img src="image/Knowledge-Panel-bak.png" class="card-img-top" alt="..." >
              </div>
            </div>
          </div>



          <div class="container mt-5 mb-5">
            <div class="row">
              <div class="col-md-12 text-center">
                <div class="row">
                  <div class="col">
                    <h2 style="    color: #363636; font-weight: 600">What Client are Saying <span style="color: #B30001;"> About Us  </span></h2>
                  </div>
                </div>
              </div>
            </div>
          </div>



          <div class="container">

          </div>


          <div class="container mt-5 mb-5">
            <div class="row">
              <div class="col-md-12 text-center">
                <div class="row">
                  <div class="col">
                    <h2 style="color: #B30001;">Blogs</h2>
                  </div>
                </div>
              </div>
            </div>
          </div>



        
<div class="container">
  

  <div id="carouselExample" class="carousel slide">
    <div class="carousel-inner">
      <div class="carousel-item active d-flex">
        <div class="col-md-4">
          <div class="card" style="width: 18rem;">
            <img src="image/fundamental_reports.png" class="card-img-top" alt="...">
            <div class="card-body">
              <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card" style="width: 18rem;">
            <img src="image/th.jpeg" class="card-img-top" alt="...">
            <div class="card-body">
              <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card" style="width: 18rem;">
            <img src="image/technical_report.png" class="card-img-top" alt="...">
            <div class="card-body">
              <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            </div>
          </div>
        </div>
      </div>
      <div class="carousel-item d-flex">
        <div class="col-md-4">
          <div class="card" style="width: 18rem;">
            <img src="image/Knowledge-Panel-bak.png" class="card-img-top" alt="...">
            <div class="card-body">
              <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card" style="width: 18rem;">
            <img src="image/fundamental_reports.png" class="card-img-top" alt="...">
            <div class="card-body">
              <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            </div>
          </div>
        </div>




      </div>
    
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>
</div>




<div class="container-fluid mt-5 pt-5 pb-5" style="background: #222222; color:#fff;
    ">
  <div class="row">
    <div class="col-md-3">
      <div class="row">
        <div class="col">
          <img src="image/MAngal-KEshav-logo.png" class="card-img-top mb-2" alt="..." style="height: 150px; width:160px; padding: 8px;
          background: #fff;
          border-radius: 10px;">
        </div>
      </div>
      <div class="row">
        <div class="col">
          <button type="button" class="btn btn-outline-danger" style="    color: #fff; border-color: #B30001;">Open an Account</button>
        </div>
      </div>
      <div class="row">
        <div class="col"><i class="fa-brands fa-facebook" style="color: #bcbcbc; width: 36px;
    height: 36px; "></i>
          <i class="fa-brands fa-twitter" style="color: #bcbcbc; width: 36px;
    height: 36px;"></i>
          <i class="fa-brands fa-linkedin-in" style="color: #bcbcbc; width: 36px;
    height: 36px;"></i>
          <i class="fa-brands fa-youtube" style="color: #bcbcbc; width: 36px;
    height: 36px;"></i>
        </div>
        
      </div>
      <div class="row">
        <div class="col">
          <p style="font-size: 12px;
          color: #fff;
          opacity: .7;
      ">Mangal Keshav Financial Services LLP (www.mangalkeshav.com) has the sole and exclusive rights to own and operate the brand MKFSLP and MKSL in India.</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <img src="image/attention-investors.jpg" class="card-img-top" alt="..." style="height: 150px; width:250px;">
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="row">
        <div class="col">
          <h4 style="font-size: 18px;
          color: #fff;
          font-weight: 600;
          opacity: .8;
          text-transform: capitalize;">Company</h4>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> Home</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right"  style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> About us</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> Careers</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> Contact us</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> Sub broker</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i>Fundamental Reports </small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style=" font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> Technical Reports</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> Blogs </small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> Media</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small  style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i>Videos</small>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="row">
        <div class="col">
          <h4 style="font-size: 18px;
          color: #fff;
          font-weight: 600;
          opacity: .8;
          text-transform: capitalize;">Services</h4>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> Demat Account</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> Trading Account</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> Alternate Investment Funds</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> NRI services</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> ipo services</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> Institutional trading</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> investment advisory </small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> mutual funds</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> portfolio management  services</small>
        </div>
      </div>
    </div>
    <div class="col-md-3">
      <div class="row">
        <div class="col">
          <h4 style="font-size: 18px;
          color: #fff;
          font-weight: 600;
          opacity: .8;
          text-transform: capitalize;">Products</h4>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> equity trading </small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> commodity trading</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> derivative</small>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <small style="font-size: 14px;
          opacity: .6;
          color: #fff;
          transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"></i> currency trading</small>
        </div>
      </div>
      
        
        <div class="row">
          <div class="col">
            <h4 style="font-size: 18px;
            color: #fff;
            font-weight: 600;
            opacity: .8;
            text-transform: capitalize;">Knowledge plan</h4>
          </div>
        </div>
        <div class="row">
          <div class="col">
            <small style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
              opacity: .6;
              color: #fff;
              transition: all .2s;"></i> Demat account</small>
          </div>
        </div>
        <div class="row">
          <div class="col">
            <small style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
              opacity: .6;
              color: #fff;
              transition: all .2s;"></i> trading account</small>
          </div>
        </div>
        <div class="row">
          <div class="col">
            <small style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
              opacity: .6;
              color: #fff;
              transition: all .2s;"></i> online share trading </small>
          </div>
        </div>
        <div class="row">
          <div class="col">
            <small style="font-size: 14px;
            opacity: .6;
            color: #fff;
            transition: all .2s;"> <i class="fa-solid fa-caret-right" style="font-size: 14px;
              opacity: .6;
              color: #fff;
              transition: all .2s;"></i> intraday account</small>
          </div>
        </div>
        <div class="row">
          <div class="col">
            <h4 style="font-size: 18px;
            color: #fff;
            font-weight: 600;
            opacity: .8;
            text-transform: capitalize;">brokerage plan</h4>
          </div> </div>
        <div class="row">
          <div class="col">
            <h4 style="font-size: 18px;
            color: #fff;
            font-weight: 600;
            opacity: .8;
            text-transform: capitalize;">closure plan</h4>
          </div>
        </div>
        <div class="row">
          <div class="col">
            <h4 style="font-size: 18px;
            color: #fff;
            font-weight: 600;
            opacity: .8;
            text-transform: capitalize;">payout request</h4>
          </div>
        </div>
        <div class="row">
          <div class="col">
            <h4 style="font-size: 18px;
            color: #fff;
            font-weight: 600;
            opacity: .8;
            text-transform: capitalize;">funds transfer</h4>
          </div>
        </div>
      </div>



     
    </div>
  </div>
</div>


<div class="container-fluid p-5" style="background: #222222;">
  <div class="row">
    <div class="col-md-10">
      <div class="row">
        <div class="col">
          <h4 style="margin-top: 20px; font-size: 18px;
          color: #fff;
          font-weight: 600;
          opacity: .8;
          text-transform: capitalize; padding-left: 50px;">Attention Investors</h4>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <p style="font-size: 12px;
          color: #fff;
          opacity: .7; padding-left: 50px;">1. No need to issue cheques by investors while subscribing to IPO. Just write the bank account number and sign in the application form to authorize your bank to make payment in case of allotment. No worries for refund as the money remain in investor’s account.</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <p  style="font-size: 12px;
          color: #fff;
          opacity: .7; padding-left: 50px;">2. Prevent Unauthorized transactions and dabba trading practices in your account</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <p style="font-size: 12px;
          color: #fff;
          opacity: .7; padding-left: 50px;">3. KYC is one time exercise while dealing in securities markets - once KYC is done through a SEBI registered intermediary (broker, DP, Mutual Fund etc.), you need not undergo the same process again when you approach another intermediary</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <p style="font-size: 12px;
          color: #fff;
          opacity: .7; padding-left: 50px;">4. AS PER SEBI DIRECTIVE (CIRCULAR NUMBERS: SEBI/HO/MIRSD/DOP/CIR/P/2020/28 & SEBI/HO/MIRSD/DOP/CIR/P/2020/143), EFFECTIVE FROM 1ST AUGUST 2020, FOR CREATION OF PLEDGE/UNPLEDGE, CLIENTS HAVE TO NECESSARILY AUTHENTICATE THE OTP RECEIVED ON THEIR MOBILE PHONES AND LINK RECEIVED ON THEIR EMAIL IDS. HENCE, ALL CLIENTS ARE REQUESTED TO KINDLY ENSURE THAT THE MOBILE NUMBER AND EMAIL ID REGISTERED WITH US ARE ACTIVE AND WORKING.</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <p style="font-size: 12px;
          color: #fff;
          opacity: .7; padding-left: 50px;">5. We do not give assured returns and neither do our APs promise assured returns to our clients</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <p style="font-size: 12px;
          color: #fff;
          opacity: .7; padding-left: 50px;">6. Please update your E-Mail and Mobile number with us</p>
        </div>
      </div>
    </div>
  </div>
</div>



<div class="container-fluid p-5" style="background: #222222;">
<div class="row">
  <div class="col-md-12">

    <div class="row">
      <div class="col">
        <h4 style="margin-top: 20px;font-size: 18px;
        color: #fff;
        font-weight: 600;
        opacity: .8;
        text-transform: capitalize; padding-left: 45px;">Risk Disclosure on Derivatives</h4>
      </div>
    </div>
    <div class="row">
      <div class="col">
        <ul style="padding-left: 80px;">
          <li style="font-size: 12px;
          color: #fff;
          opacity: .7;"> 9 out of 10 individual traders in equity Futures and Options Segment, incurred net losses.</li>
          <li style="font-size: 12px;
          color: #fff;
          opacity: .7;"> On an average, loss makers registered net trading loss close to ₹50,000.</li>
          <li style="font-size: 12px;
          color: #fff;
          opacity: .7;"> Over and abovethe net trading losses incurred, loss makers expended anadditional 28%of net trading losses as transaction costs.</li>
          <li style="font-size: 12px;
          color: #fff;
          opacity: .7;">Those making net trading profits,incurredbetween 15% to 50%of such profitsas transaction cost.</li>
        </ul>
      </div>
    </div>
    
  </div>
</div>
</div>

<div class="container-fluid pb-5 " style="background: #222222;">
  <div class="row">
    <div class="col-md-10">
      <div class="row">
        <div class="col">
           <p style="    font-size: 12px;
           color: #fff;
           opacity: .7; padding-left: 80px;">Source:</p>
        </div>
      </div>
      <div class="row">
        <div class="col">
          <a href="" style="color: #428bca;text-decoration: none;
    background-color: transparent; font-size: 12px; opacity: .7; padding-left: 80px;">1. SEBI study dated January 25, 2023 on “Analysis of Profit and Loss of Individual Traders dealing in equity Futures and Options (F&O) Segment”, wherein Aggregate Level findings 
    </a>
    <a href="" style="color: #428bca;text-decoration: none;
    background-color: transparent; font-size: 12px; opacity: .7; padding-left: 80px;">are based on annual Profit/Loss incurred by individual traders in equity F&O during FY 2021-22.</a>
        </div>
      </div>
    </div>
  </div>
</div>


<div class="container-fluid" style="    background-color: #1b1b1b;">
<div class="row">
  <div class="col-md-12">
    <div class="row">
      <div class="col">
        <h4 style="margin-top: 20px;font-size: 18px;
        color: #fff;
        font-weight: 600;
        opacity: .8;
        text-transform: capitalize; padding-left: 80px;"> Useful links</h4>
      </div>
    </div>
    <div class="row">
      <div class="col" style="padding-left: 80px;">
        <a href="" style="font-size: 14px;
        opacity: .6;
        color: #fff;
        transition: all .2s;text-decoration: none;
        background-color: transparent;  border-right: solid 1px #585858 !important; float: left !important;
        padding: 2px 29px 2px 25px !important; ">NSE</a>
        <a href="" style="font-size: 14px;
        opacity: .6;
        color: #fff;
        transition: all .2s;text-decoration: none;
        background-color: transparent;  border-right: solid 1px #585858 !important; float: left !important;
        padding: 2px 29px 2px 25px !important; ">BSE</a>
        <a href="" style="font-size: 14px;
        opacity: .6;
        color: #fff;
        transition: all .2s;text-decoration: none;
        background-color: transparent;  border-right: solid 1px #585858 !important; float: left !important;
        padding: 2px 29px 2px 25px !important; ">NSDL</a>
        <a href="" style="font-size: 14px;
        opacity: .6;
        color: #fff;
        transition: all .2s;text-decoration: none;
        background-color: transparent;  border-right: solid 1px #585858 !important; float: left !important;
        padding: 2px 29px 2px 25px !important; ">CDSL </a>
        <a href="" style="font-size: 14px;
        opacity: .6;
        color: #fff;
        transition: all .2s;text-decoration: none;
        background-color: transparent;  border-right: solid 1px #585858 !important; float: left !important;
        padding: 2px 29px 2px 25px !important; ">SEBI</a>
        <a href="" style="font-size: 14px;
        opacity: .6;
        color: #fff;
        transition: all .2s;text-decoration: none;
        background-color: transparent;  border-right: solid 1px #585858 !important; float: left !important;
        padding: 2px 29px 2px 25px !important; ">AMFI</a>
        <a href="" style="font-size: 14px;
        opacity: .6;
        color: #fff;
        transition: all .2s;text-decoration: none;
        background-color: transparent;  border-right: solid 1px #585858 !important; float: left !important;
        padding: 2px 29px 2px 25px !important; ">smart ODR</a>
      </div>
     
    </div>
    <div class="row pt-3">
      <div class="col" style="padding-left: 90px;">
        <a href="" style="color: #9e9e9e;
    opacity: .8; text-decoration: none;
    background-color: transparent;">Privacy Policy</a>
        <a href="" style="color: #9e9e9e;
        opacity: .8; text-decoration: none;
        background-color: transparent;">Disclaimer</a>
        <a href="" style="color: #9e9e9e;
        opacity: .8; text-decoration: none;
        background-color: transparent;">Compliance</a>
        <a href="" style="color: #9e9e9e;
        opacity: .8; text-decoration: none;
        background-color: transparent;">Terms $ Conditions</a>
        <a href="" style="color: #9e9e9e;
        opacity: .8; text-decoration: none;
        background-color: transparent;">Sitemap</a>
      </div>
      <div class="col">
        <p style="font-size: 14px;
        opacity: .5;
        color: #fff;">
          Copyright © 2020 Mangal Keshav Financial Services LLP. All rights reserved.
       </p>
      </div>
    </div>
  </div>
</div>


</div>
        


    

    <script src="script.js"></script>
</body>
</html>
